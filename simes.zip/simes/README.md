📚 SIMES: Sistem Informasi Manajemen Event dan Seminar
SIMES adalah aplikasi berbasis PHP Native dan MySQL yang dirancang untuk mengelola seluruh alur event, mulai dari pendaftaran peserta, ticketing, pembayaran (simulasi via WhatsApp), hingga check-in di lokasi.

⚙️ Persyaratan Sistem
Pastikan lingkungan lokal Anda memenuhi persyaratan berikut:
- Web Server: Apache (Direkomendasikan menggunakan XAMPP atau Laragon).
- Bahasa Pemrograman: PHP 8.0 atau lebih tinggi.
- Database: MySQL / MariaDB.
- Web Browser: Modern (Chrome, Firefox, Edge).

🚀 Panduan Instalasi (Setup)
Ikuti langkah-langkah berikut untuk menjalankan proyek SIMES di lingkungan lokal Anda.

Langkah 1: Siapkan Folder Proyek
1. Ekstrak semua file proyek SIMES ke dalam folder root server lokal Anda.
    - Jika menggunakan XAMPP, letakkan di C:\xampp\htdocs\simes\.
    - Jika menggunakan Laragon, letakkan di C:\laragon\www\simes\.
2. Buka browser dan pastikan Anda dapat mengakses folder tersebut: http://localhost/simes/.

Langkah 2: Konfigurasi Database
1. Buka phpMyAdmin melalui browser Anda (http://localhost/phpmyadmin).
2. Buat database baru dengan nama: simes_db.
3. Impor skema database:
    - Klik pada database simes_db yang baru dibuat.
    - Pilih tab Import.
    - Pilih file simes_db.sql (File ini harusnya berisi skema tabel dan data awal yang Anda buat).
    - Klik Go.

Langkah 3: Konfigurasi PHP
1. Buka file koneksi utama: simes/config.php.
2. Sesuaikan variabel koneksi database jika Anda tidak menggunakan username dan password default (root / kosong):
// Konfigurasi Database (Ganti jika perlu)
$host = "localhost";
$user = "root";      
$pass = "";          // Ganti jika ada password
$db   = "simes_db";  
// URL dasar project (Pastikan path folder Anda benar: simes/)
$base_url = "http://localhost/simes/"; // Pastikan ini sesuai dengan folder Anda
//
3. Pastikan folder simes/uploads/ sudah ada dan memiliki izin tulis (writable).

🔑 Akun Default (Login)
Setelah instalasi selesai dan Anda menjalankan SQL seeding data awal, Anda dapat login menggunakan akun-akun berikut (semua password harus disesuaikan dengan hash yang terakhir Anda gunakan agar valid):
Peran,Email,Password,Dashboard
Super Admin,admin@simes.com,[PASSWORD VALID],simes/admin/dashboard.php
Panitia Demo,panitia@simes.com,[PASSWORD VALID],simes/panitia/dashboard.php
Peserta,peserta@simes.com,[PASSWORD VALID],simes/index.php

Catatan Penting: Jika akun default di atas gagal login, gunakan akun yang Anda buat melalui register.php (yang terbukti hash-nya valid) lalu ubah role-nya menjadi admin di phpMyAdmin.

🛠️ Struktur Folder Utama
Folder/File,Deskripsi
admin/,"Panel Kontrol untuk Super Admin (Manajemen User, Laporan Keuangan)."
panitia/,"Panel Kontrol untuk Panitia Event (Buat/Edit Event, Verifikasi Pembayaran, Check-in)."
uploads/,Tempat penyimpanan file gambar poster event.
config.php,"Koneksi database, fungsi helper, dan variabel global ($base_url)."
index.php,Halaman utama / Marketplace Event untuk peserta.
login.php,Form dan logika autentikasi pengguna.
register.php,Form pendaftaran akun peserta baru.
checkout.php,Logika proses pembelian tiket dan redirect ke WhatsApp Panitia.
simes_db.sql,Skema tabel database dan data awal (Wajib diimpor).

📝 Kontak
Jika Anda memiliki pertanyaan, silakan hubungi developer terkait.
1. Nama Proyek: SIMES
2. Versi: 1.0 (Initial Build)