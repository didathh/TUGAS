<?php
require '../config.php';
checkRole(['panitia', 'admin']);
$panitia_id = $_SESSION['user_id'];

$sql_peserta = "
    SELECT u.name, u.email, u.phone, e.title, tt.nama_tiket, t.jumlah, t.total_bayar, t.tgl_transaksi
    FROM transaksi t
    JOIN users u ON t.user_id = u.id
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    WHERE e.organizer_id = '$panitia_id' AND t.status = 'PAID'
    ORDER BY t.tgl_transaksi DESC";
$result_peserta = mysqli_query($conn, $sql_peserta);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Peserta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="absensi.php" class="<?php echo ($current_page == 'absensi.php') ? 'active' : ''; ?>">
                <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
            </a>
            <a href="verifikasi_pembayaran.php" class="<?php echo ($current_page == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
                <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
            </a>
            <a href="peserta_event.php" class="<?php echo ($current_page == 'peserta_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill me-2"></i> Daftar Peserta
            </a>
            <a href="buat_event.php" class="<?php echo ($current_page == 'buat_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
            </a>
            <a href="kelola_event.php" class="<?php echo ($current_page == 'kelola_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-list-check me-2"></i> Kelola Event Saya
            </a>
            <a href="laporan_event.php" class="<?php echo ($current_page == 'laporan_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
            </a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>
    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #1d3557, #457b9d);">
            <h3><i class="bi bi-people-fill me-2"></i> Daftar Pembeli Tiket</h3>
            <p class="mb-0">Daftar semua peserta yang telah membeli tiket dan berstatus PAID.</p>
        </div>
        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>Nama</th><th>Event</th><th>Tiket</th><th>Bayar</th><th>Kontak</th></tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result_peserta)): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($row['name']) ?></strong></td>
                            <td><?= htmlspecialchars($row['title']) ?></td>
                            <td><span class="badge bg-info text-dark"><?= htmlspecialchars($row['nama_tiket']) ?></span></td>
                            <td><?= formatRupiah($row['total_bayar']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?><br><small><?= htmlspecialchars($row['phone']) ?></small></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>