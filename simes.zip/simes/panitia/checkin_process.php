<?php
require '../config.php';
checkLogin();
if ($_SESSION['role'] != 'panitia') { header("Location: " . $base_url . "index.php"); exit; }

if (isset($_POST['qr_code'])) {
    $qr_code = clean($_POST['qr_code']);
    $panitia_id = $_SESSION['user_id'];
    
    // Cek apakah transaksi kode ini valid, sudah dibayar, dan milik event Panitia ini
    $query = mysqli_query($conn, "SELECT t.id, t.status, e.title 
                                  FROM transaksi t 
                                  JOIN events e ON t.event_id = e.id 
                                  WHERE t.transaction_code = '$qr_code' 
                                  AND e.organizer_id = '$panitia_id'");

    if (mysqli_num_rows($query) == 0) {
        $msg = "Kode Transaksi/QR tidak ditemukan atau bukan untuk event Anda.";
        $type = 'danger';
    } else {
        $trx = mysqli_fetch_assoc($query);
        $trx_id = $trx['id'];

        if ($trx['status'] == 'paid') {
            // Lakukan Check-in
            mysqli_query($conn, "UPDATE transaksi SET status = 'checked_in' WHERE id = '$trx_id'");
            $msg = "Check-in Berhasil! Peserta untuk event '{$trx['title']}' telah masuk.";
            $type = 'success';
        } else if ($trx['status'] == 'checked_in') {
            $msg = "Gagal! Tiket ini sudah pernah di Check-in sebelumnya.";
            $type = 'warning';
        } else {
            $msg = "Gagal! Tiket ini belum diverifikasi pembayarannya (status: {$trx['status']}).";
            $type = 'danger';
        }
    }
    
    // Redirect kembali ke dashboard panitia dengan pesan
    header("Location: dashboard.php?msg=" . urlencode($msg) . "&type=$type");
    exit;
}
?>