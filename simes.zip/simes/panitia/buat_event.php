<?php
// panitia/buat_event.php

require '../config.php';

// Pastikan pengguna login
checkLogin(); 

// Pastikan role adalah panitia atau admin. 
// Ini akan menggunakan checkRole di config.php yang me-redirect ke index.php jika gagal.
checkRole(['panitia', 'admin']); 

$msg = "";
$panitia_id = $_SESSION['user_id'];
$current_page = basename(__FILE__); 
// ...

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_event'])) {
    // 1. Ambil Data Event
    $title = clean($_POST['title']);
    $description = clean($_POST['description']);
    $event_date = clean($_POST['event_date']);
    $event_time = clean($_POST['event_time']);
    $location = clean($_POST['location']);
    $event_type = clean($_POST['event_type']);
    $wa_panitia = clean($_POST['wa_panitia']);
    $ticket_names = $_POST['ticket_name'];
    $ticket_prices = $_POST['ticket_price'];
    $ticket_quotas = $_POST['ticket_quota'];

    $full_datetime = $event_date . ' ' . $event_time;
    
    // --- LOGIKA UPLOAD GAMBAR YANG DIKOREKSI FINAL ---
    $image_name = '';

    // VALIDASI FORMAT WA (628xxxxxxxxxx)
    if (!preg_match('/^628[0-9]{8,13}$/', $wa_panitia)) {
        $msg = "<div class='alert alert-danger'>
                    Nomor WhatsApp tidak valid. Gunakan format <strong>628xxxxxxxxxx</strong>.
                </div>";
    }

    // Cek apakah file diunggah dan tidak ada error PHP
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        
        // 1. Tentukan Path Absolut untuk tujuan
        $target_dir_absolute = __DIR__ . "/../uploads/event_images/"; 

        // 2. Cek dan Buat Direktori jika belum ada
        if (!is_dir($target_dir_absolute)) {
            // Mode 0777 memberikan izin penuh (cocok untuk lingkungan lokal)
            if (!mkdir($target_dir_absolute, 0777, true)) {
                $msg = "<div class='alert alert-danger'>Gagal membuat folder upload. Periksa izin folder **uploads/event_images/**.</div>";
            }
        }
        
        if (empty($msg)) {
            // 3. Tentukan Nama File Unik
            $file_info = pathinfo($_FILES["image"]["name"]);
            $unique_name = time() . "_" . clean($file_info['filename']) . "." . strtolower($file_info['extension']);
            $target_file = $target_dir_absolute . $unique_name;
            
            // 4. Pindahkan File
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $image_name = $unique_name;
            } else {
                // Gagal move (misalnya izin folder, atau file hilang)
                $msg = "<div class='alert alert-danger'>Gagal memindahkan file yang diunggah. Pastikan folder **uploads/event_images/** memiliki izin tulis (0777).</div>";
            }
        }
    } else if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        // Menangani error PHP upload lainnya (misalnya file terlalu besar)
        $msg = "<div class='alert alert-danger'>Kesalahan saat mengunggah gambar. Error code: " . $_FILES['image']['error'] . "</div>";
    } else {
        // Jika file required di HTML tetapi tidak diunggah, ini adalah fallback
        $msg = "<div class='alert alert-danger'>Gambar utama event wajib diunggah.</div>";
    }
    // --- AKHIR LOGIKA UPLOAD GAMBAR ---

    // Lanjutkan hanya jika tidak ada pesan error dari proses upload
    if (empty($msg)) {
        // 2. Insert Data Event
        // KOREKSI: Menggunakan kolom 'image' (sesuai database Anda)
        $sql_event = "INSERT INTO events 
        (organizer_id, title, description, event_date, location, event_type, wa_panitia, image, status)
        VALUES 
        ('$panitia_id', '$title', '$description', '$full_datetime', '$location', '$event_type', '$wa_panitia', '$image_name', 'pending')";
        
        if (mysqli_query($conn, $sql_event)) {
            $event_id = mysqli_insert_id($conn);
            $success = true;

            // 3. Insert Data Tipe Tiket
            for ($i = 0; $i < count($ticket_names); $i++) {
                $name = clean($ticket_names[$i]);
                $price = clean($ticket_prices[$i]);
                $quota = clean($ticket_quotas[$i]);
                
                if (!empty($name) && $quota > 0) {
                    $sql_tiket = "INSERT INTO tipe_tiket (event_id, nama_tiket, harga, kuota)
                                  VALUES ('$event_id', '$name', '$price', '$quota')";
                    if (!mysqli_query($conn, $sql_tiket)) {
                        $success = false;
                        break; 
                    }
                }
            }
            
            if ($success) {
                // Gunakan session untuk menyimpan pesan agar bisa dibaca setelah redirect
                $_SESSION['message'] = "success: Event **$title** berhasil dibuat! Menunggu verifikasi admin.";
                header("Location: kelola_event.php"); // Redirect ke kelola event
                exit;
            } else {
                // Rollback event jika tiket gagal
                mysqli_query($conn, "DELETE FROM events WHERE id = '$event_id'");
                $msg = "<div class='alert alert-danger'>Gagal membuat tiket. Event dibatalkan.</div>";
            }

        } else {
            // Error query SQL INSERT events
            $msg = "<div class='alert alert-danger'>Gagal membuat event: " . mysqli_error($conn) . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Buat Event Baru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> 
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="absensi.php" class="<?php echo ($current_page == 'absensi.php') ? 'active' : ''; ?>">
                <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
            </a>
            <a href="verifikasi_pembayaran.php" class="<?php echo ($current_page == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
                <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
            </a>
            <a href="peserta_event.php" class="<?php echo ($current_page == 'peserta_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill me-2"></i> Daftar Peserta
            </a>
            <a href="buat_event.php" class="<?php echo ($current_page == 'buat_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
            </a>
            <a href="kelola_event.php" class="<?php echo ($current_page == 'kelola_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-list-check me-2"></i> Kelola Event Saya
            </a>
            <a href="laporan_event.php" class="<?php echo ($current_page == 'laporan_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
            </a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #ffc107, #ff9800);">
            <h3><i class="bi bi-plus-circle me-2"></i> Buat Event Baru</h3>
            <p class="mb-0">Isi detail event Anda untuk diajukan ke admin.</p>
        </div>
        
        <?php 
        // Tampilkan pesan error/sukses dari proses POST
        if (!empty($msg)) {
            echo $msg;
        }
        
        // Tampilkan pesan jika ada setelah redirect (misalnya dari kelola_event.php)
        if (isset($_SESSION['message'])): 
            list($type, $msg_text) = explode(': ', $_SESSION['message'], 2);
            $alert_class = ($type == 'success') ? 'alert-success' : 'alert-danger';
        ?>
            <div class="alert <?= $alert_class ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($msg_text) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php unset($_SESSION['message']); endif; ?>


        <form method="POST" enctype="multipart/form-data">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-primary text-white">Detail Event</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Judul Event</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="description" class="form-control" rows="4" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal</label>
                            <input type="date" name="event_date" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Waktu</label>
                            <input type="time" name="event_time" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Lokasi</label>
                        <input type="text" name="location" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tipe Event</label>
                        <select name="event_type" class="form-select" required>
                            <option value="">Pilih Tipe</option>
                            <option value="seminar">Seminar</option>
                            <option value="konser">Konser</option>
                            <option value="workshop">Workshop</option>
                            <option value="pameran">Pameran</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">WhatsApp Panitia</label>
                        <input type="text"
                            name="wa_panitia"
                            class="form-control"
                            placeholder="628xxxxxxxxxx"
                            required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Gambar Utama</label>
                        <input type="file" name="image" class="form-control" accept="image/*" required>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    Tipe Tiket
                    <button type="button" class="btn btn-light btn-sm" id="addTicket"><i class="bi bi-plus"></i> Tambah Tiket</button>
                </div>
                <div class="card-body" id="ticketContainer">
                    <div class="ticket-entry row g-3 mb-3 p-3 border rounded">
                        <div class="col-md-5">
                            <label class="form-label">Nama Tiket (Contoh: VIP)</label>
                            <input type="text" name="ticket_name[]" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Harga (0 jika gratis)</label>
                            <input type="number" name="ticket_price[]" class="form-control" value="0" min="0" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Kuota</label>
                            <input type="number" name="ticket_quota[]" class="form-control" value="100" min="1" required>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-danger w-100 remove-ticket"><i class="bi bi-x"></i></button>
                        </div>
                    </div>
                </div>
            </div>

            <button type="submit" name="submit_event" class="btn btn-primary btn-lg w-100 mb-5">Ajukan Event ke Admin</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Logika Menambahkan Tiket
        document.getElementById('addTicket').addEventListener('click', function() {
            const container = document.getElementById('ticketContainer');
            // Clone elemen yang ada (template)
            const newEntry = document.querySelector('.ticket-entry').cloneNode(true);
            
            // Reset nilai input
            newEntry.querySelectorAll('input').forEach(input => {
                if(input.name.includes('price')) {
                    input.value = '0'; // Default harga 0
                } else if(input.name.includes('quota')) {
                    input.value = '100'; // Default kuota 100
                } else {
                    input.value = ''; // Kosongkan nama tiket
                }
            });
            
            // Re-attach event listener untuk tombol hapus di entri baru
            newEntry.querySelector('.remove-ticket').addEventListener('click', removeTicketHandler);
            
            container.appendChild(newEntry);
            updateRemoveButtons();
        });

        // Handler untuk menghapus tiket
        function removeTicketHandler(e) {
            const container = document.getElementById('ticketContainer');
            const entryToRemove = this.closest('.ticket-entry');

            if (container.children.length > 1) {
                entryToRemove.remove();
                updateRemoveButtons();
            } else {
                alert('Minimal harus ada 1 tipe tiket.');
            }
        }
        
        function updateRemoveButtons() {
            const container = document.getElementById('ticketContainer');
            const groups = container.querySelectorAll('.ticket-entry');
            groups.forEach(group => {
                const removeBtn = group.querySelector('.remove-ticket');
                if (groups.length === 1) {
                    removeBtn.disabled = true;
                } else {
                    removeBtn.disabled = false;
                }
            });
        }


        // Attach event listener ke tombol hapus yang sudah ada di halaman awal
        document.querySelectorAll('.remove-ticket').forEach(button => {
            button.addEventListener('click', removeTicketHandler);
        });
        
        // Inisialisasi tombol hapus saat halaman dimuat
        updateRemoveButtons();

    </script>
</body>
</html>