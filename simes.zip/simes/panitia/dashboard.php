<?php
// panitia/dashboard.php

require '../config.php';

// Pastikan pengguna login
checkLogin(); 

// Pastikan role adalah panitia atau admin. 
checkRole(['panitia', 'admin']); 

$msg = "";
$panitia_id = $_SESSION['user_id'];
$current_page = basename(__FILE__); 

// --- LOGIKA STATISTIK PANITIA ---
// 1. Total Event Aktif
$sql_event_count = "SELECT COUNT(id) as total FROM events WHERE organizer_id = '$panitia_id' AND status = 'published'";
$total_events = mysqli_fetch_assoc(mysqli_query($conn, $sql_event_count))['total'] ?? 0;

// 2. Tiket Terjual (PAID)
$sql_sold_count = "
    SELECT SUM(t.jumlah) as total_sold
    FROM transaksi t JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id JOIN events e ON tt.event_id = e.id
    WHERE e.organizer_id = '$panitia_id' AND t.status = 'PAID'
";
$total_sold = mysqli_fetch_assoc(mysqli_query($conn, $sql_sold_count))['total_sold'] ?? 0;

// 3. Total Check-in
$sql_checkin_count = "
    SELECT COUNT(a.id) as total_checkin
    FROM absensi a JOIN transaksi t ON a.transaksi_id = t.id JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id JOIN events e ON tt.event_id = e.id
    WHERE e.organizer_id = '$panitia_id'
";
$total_checkin = mysqli_fetch_assoc(mysqli_query($conn, $sql_checkin_count))['total_checkin'] ?? 0;

// 4. Estimasi Omset (Total bayar dari status PAID)
$sql_omset = "
    SELECT SUM(t.total_bayar) as omset
    FROM transaksi t JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id JOIN events e ON tt.event_id = e.id
    WHERE e.organizer_id = '$panitia_id' AND t.status = 'PAID'
";
$total_omset = mysqli_fetch_assoc(mysqli_query($conn, $sql_omset))['omset'] ?? 0;

// 5. Pembayaran Pending
$sql_pending_payment = "
    SELECT COUNT(t.id) as pending_count
    FROM transaksi t JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id JOIN events e ON tt.event_id = e.id
    WHERE e.organizer_id = '$panitia_id' AND t.status = 'PENDING'
";
$pembayaran_pending = mysqli_fetch_assoc(mysqli_query($conn, $sql_pending_payment))['pending_count'] ?? 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Panitia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="absensi.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'absensi.php' || basename($_SERVER['PHP_SELF']) == 'absensi_scan.php') ? 'active' : ''; ?>">
                <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
            </a>
            <a href="verifikasi_pembayaran.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
                <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
            </a>
            <a href="peserta_event.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'peserta_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill me-2"></i> Daftar Peserta
            </a>
            <a href="buat_event.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'buat_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
            </a>
            <a href="kelola_event.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'kelola_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-list-check me-2"></i> Kelola Event Saya
            </a>
            <a href="laporan_event.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'laporan_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
            </a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #0d6efd, #0dcaf0);">
            <h3>Halo, Panitia <?= htmlspecialchars($_SESSION['name']) ?>!</h3>
            <p class="mb-0">Selamat datang di Panel Event Anda. Siap menyelenggarakan event hebat hari ini?</p>
        </div>

        <div class="row g-4">
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #0d6efd!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted">Total Event Aktif</h6><h2 class="fw-bold text-primary"><?= $total_events ?></h2></div>
                        <div class="fs-1 text-primary opacity-25"><i class="bi bi-calendar-event"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #198754!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted">Tiket Terjual</h6><h2 class="fw-bold text-success"><?= $total_sold ?></h2></div>
                        <div class="fs-1 text-success opacity-25"><i class="bi bi-ticket-fill"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #ffc107!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted">Total Check-in</h6><h2 class="fw-bold text-warning"><?= $total_checkin ?></h2></div>
                        <div class="fs-1 text-warning opacity-25"><i class="bi bi-person-check-fill"></i></div>
                    </div>
                    <a href="absensi.php" class="small text-decoration-none mt-2 d-block text-warning">Buka Absensi &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #0dcaf0!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted">Estimasi Omset</h6><h2 class="fw-bold text-info"><?= formatRupiah($total_omset) ?></h2></div>
                        <div class="fs-1 text-info opacity-25"><i class="bi bi-currency-dollar"></i></div>
                    </div>
                </div>
            </div>
             <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #dc3545!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="text-muted">Pembayaran Pending</h6><h2 class="fw-bold text-danger"><?= $pembayaran_pending ?></h2></div>
                        <div class="fs-1 text-danger opacity-25"><i class="fas fa-hourglass-half"></i></div> 
                    </div>
                    <a href="verifikasi_pembayaran.php" class="small text-decoration-none mt-2 d-block text-danger">Verifikasi Sekarang &rarr;</a>
                </div>
            </div>
        </div>
        
        <h3 class="mt-5 mb-3 text-primary">Event Terbaru Saya</h3>
        <?php 
        $events_list = mysqli_query($conn, "SELECT id, title, event_date, status FROM events WHERE organizer_id = '$panitia_id' ORDER BY id DESC LIMIT 5");
        
        if (mysqli_num_rows($events_list) == 0): ?>
            <div class="alert alert-info text-center shadow-sm border-0">Anda belum membuat event apapun. Klik "Buat Event Baru" di sidebar.</div>
        <?php else: ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light"><tr><th>Event</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($events_list)): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['title']) ?></td>
                                <td><?= date('d M Y', strtotime($row['event_date'])) ?></td>
                                <td>
                                    <?php 
                                    $status_badge = ['pending' => 'warning', 'published' => 'success', 'rejected' => 'danger', 'deletion_requested' => 'info'];
                                    $status_display = str_replace('_', ' ', $row['status']);
                                    echo '<span class="badge bg-' . ($status_badge[$row['status']] ?? 'secondary') . '">' . ucwords($status_display) . '</span>';
                                    ?>
                                </td>
                                <td><a href="kelola_event.php?edit=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary">Kelola</a></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>