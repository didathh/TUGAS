<?php
require '../config.php';
checkLogin();
if ($_SESSION['role'] != 'panitia') { header("Location: " . $base_url . "index.php"); exit; }

$panitia_id = $_SESSION['user_id'];

if (!isset($_GET['id'])) {
    header("Location: kelola_event.php");
    exit;
}

$event_id = clean($_GET['id']);

// Ambil data event dan pastikan event ini milik Panitia yang login
$q_event = mysqli_query($conn, "SELECT * FROM events WHERE id = '$event_id' AND organizer_id = '$panitia_id'");
if (mysqli_num_rows($q_event) == 0) {
    die("Event tidak ditemukan atau bukan milik Anda.");
}
$event = mysqli_fetch_assoc($q_event);


// --- PROSES UPDATE ---
if (isset($_POST['update_event'])) {
    $title = clean($_POST['title']);
    $description = clean($_POST['description']);
    $event_date = clean($_POST['event_date']);
    $location = clean($_POST['location']);
    $wa_panitia = clean($_POST['wa_panitia']);
    $price = clean($_POST['price']);
    $capacity = clean($_POST['capacity']);
    
    $image_name_db = $event['image']; // Tetap gunakan nama gambar lama by default
    $uploadOk = 1;

    if (!preg_match('/^628[0-9]{8,13}$/', $wa_panitia)) {
    $error = "Nomor WhatsApp tidak valid. Gunakan format 628xxxxxxxxxx.";
    $uploadOk = 0;
    }

    // Cek apakah ada file gambar baru diupload
    if ($_FILES['image']['name'] != "") {
        $target_dir = "../uploads/";
        $image_file = basename($_FILES["image"]["name"]);
        $new_image_name = time() . '_' . $image_file;
        $target_file = $target_dir . $new_image_name;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_name_db = $new_image_name;
            
            // Hapus file gambar lama jika ada
            if ($event['image'] && file_exists($target_dir . $event['image'])) {
                unlink($target_dir . $event['image']);
            }
        } else {
            $error = "Gagal mengunggah gambar baru.";
            $uploadOk = 0;
        }
    }

    if ($uploadOk) {
        $sql = "UPDATE events SET 
            title = '$title',
            description = '$description',
            event_date = '$event_date',
            location = '$location',
            wa_panitia = '$wa_panitia',
            image = '$image_name_db'
            WHERE id = '$event_id'";
                
        if (mysqli_query($conn, $sql)) {
            $success = "Event berhasil diperbarui!";
            // Refresh data event setelah update
            $q_event = mysqli_query($conn, "SELECT * FROM events WHERE id = '$event_id'");
            $event = mysqli_fetch_assoc($q_event); 
        } else {
            $error = "Gagal memperbarui event: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Event: </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= $base_url ?>style.css" rel="stylesheet"> 
</head>
<body>
    <div class="container mt-5">
        <h3><i class="bi bi-pencil-square"></i> Edit Event: <?= $event['title'] ?></h3>
        <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Gambar Saat Ini</label><br>
                <img src="<?= $base_url ?>uploads/<?= $event['image'] ?>" alt="Poster" style="max-width: 200px; height: auto;" class="img-thumbnail mb-2">
            </div>
            
            <div class="mb-3"><label>Ganti Gambar Poster</label><input type="file" name="image" class="form-control"></div>
            
            <div class="mb-3"><label>Judul Event</label><input type="text" name="title" class="form-control" value="<?= $event['title'] ?>" required></div>
            <div class="mb-3"><label>Deskripsi</label><textarea name="description" class="form-control" rows="3" required><?= $event['description'] ?></textarea></div>
            
            <input type="text"
            name="wa_panitia"
            class="form-control"
            value="<?= htmlspecialchars($event['wa_panitia']) ?>"
            required>

            <div class="row">
                <div class="col-md-6 mb-3"><label>Tanggal</label><input type="date" name="event_date" class="form-control" value="<?= $event['event_date'] ?>" required></div>
                <div class="col-md-6 mb-3"><label>Lokasi</label><input type="text" name="location" class="form-control" value="<?= $event['location'] ?>" required></div>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-3"><label>Harga Tiket (Rp)</label><input type="number" name="price" class="form-control" value="<?= $event['price'] ?>" required></div>
                <div class="col-md-4 mb-3"><label>Kapasitas</label><input type="number" name="capacity" class="form-control" value="<?= $event['capacity'] ?>" required></div>
                <div class="col-md-4 mb-3"><label>Status</label><input type="text" class="form-control" value="<?= ucfirst($event['status']) ?>" disabled></div>
            </div>
            
            <button type="submit" name="update_event" class="btn btn-success">Simpan Perubahan</button>
            <a href="kelola_event.php" class="btn btn-secondary">Batal / Kembali</a>
        </form>
    </div>
</body>
</html>