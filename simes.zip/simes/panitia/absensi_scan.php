<?php
// panitia/absensi_scan.php

require '../config.php';
checkRole(['panitia', 'admin']);

$event_id = $_GET['event_id'] ?? '';
$panitia_id = $_SESSION['user_id'];
$current_page = 'absensi.php'; // Digunakan untuk mengaktifkan link "Sistem Absensi" di sidebar

// Ambil data event
$event_data = null;
if (!empty($event_id)) {
    $sql_event = "SELECT title FROM events WHERE id = '$event_id' AND organizer_id = '$panitia_id'";
    $result_event = mysqli_query($conn, $sql_event);
    $event_data = mysqli_fetch_assoc($result_event);

    if (!$event_data) {
        // Jika event tidak ditemukan atau bukan event panitia ini
        $event_id = '';
    }
}

// Simulasikan logika proses absensi (Jika ada POST request)
$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['transaksi_id'])) {
    $transaksi_id = clean($_POST['transaksi_id']);
    $event_id_post = clean($_POST['event_id']);
    
    // 1. Cek Transaksi (status PAID, dan tiket milik event ini)
    $sql_check_trx = "
        SELECT t.id, t.user_id 
        FROM transaksi t
        JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
        WHERE kode_transaksi = '$transaksi_id' 
        AND tt.event_id = '$event_id_post' 
        AND t.status = 'PAID'";
    $res_check_trx = mysqli_query($conn, $sql_check_trx);
    
    if (mysqli_num_rows($res_check_trx) > 0) {
        $trx_row = mysqli_fetch_assoc($res_check_trx);
        $transaksi_pk_id = $trx_row['id'];
        
        // 2. Cek apakah sudah pernah absen
        $sql_check_abs = "SELECT id FROM absensi WHERE transaksi_id = '$transaksi_pk_id'";
        $res_check_abs = mysqli_query($conn, $sql_check_abs);

        if (mysqli_num_rows($res_check_abs) == 0) {
            // 3. Lakukan Absensi (Insert)
            $insert_absensi = "INSERT INTO absensi (transaksi_id, panitia_id, check_in_time) VALUES ('$transaksi_pk_id', '$panitia_id', NOW())";
            if (mysqli_query($conn, $insert_absensi)) {
                $msg = ['type' => 'success', 'text' => "Check-in berhasil! Kode: **$transaksi_id**."];
            } else {
                $msg = ['type' => 'danger', 'text' => "Gagal menyimpan absensi ke database."];
            }
        } else {
            $msg = ['type' => 'warning', 'text' => "Kode **$transaksi_id** sudah pernah Check-in sebelumnya."];
        }

    } else {
        $msg = ['type' => 'danger', 'text' => "Kode Transaksi **$transaksi_id** tidak valid, belum bayar, atau bukan untuk event ini."];
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Sistem Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="absensi.php" class="<?php echo ($current_page == 'absensi.php') ? 'active' : ''; ?>">
                <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
            </a>
            <a href="verifikasi_pembayaran.php" class="<?php echo ($current_page == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
                <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
            </a>
             <a href="peserta_event.php" class="<?php echo ($current_page == 'peserta_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill me-2"></i> Daftar Peserta
            </a>
            <a href="buat_event.php" class="<?php echo ($current_page == 'buat_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
            </a>
            <a href="kelola_event.php" class="<?php echo ($current_page == 'kelola_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-list-check me-2"></i> Kelola Event Saya
            </a>
            <a href="laporan_event.php" class="<?php echo ($current_page == 'laporan_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
            </a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>
    
    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #28a745, #20c997);">
            <h3><i class="bi bi-qr-code-scan me-2"></i> Check-in Peserta</h3>
            <p class="mb-0">Absensi untuk Event: **<?= htmlspecialchars($event_data['title'] ?? 'Pilih Event Terlebih Dahulu') ?>**</p>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= $msg['type'] ?> alert-dismissible fade show" role="alert">
                <?= $msg['text'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (empty($event_id)): ?>
            <div class="alert alert-danger text-center shadow-sm">
                <h4>Event Belum Dipilih</h4>
                <p>Silakan kembali ke menu <a href="absensi.php" class="alert-link">Sistem Absensi</a> dan pilih event yang ingin Anda kelola absensinya.</p>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white fw-bold"><i class="bi bi-keyboard me-1"></i> Input Kode Transaksi Manual</div>
                        <div class="card-body">
                            <form action="absensi_scan.php?event_id=<?= $event_id ?>" method="POST">
                                <input type="hidden" name="event_id" value="<?= $event_id ?>">
                                <div class="mb-3">
                                    <label for="transaksi_id" class="form-label">Kode Transaksi (TRX...)</label>
                                    <input type="text" name="transaksi_id" id="transaksi_id" class="form-control form-control-lg" placeholder="TRX12345678" required>
                                </div>
                                <button type="submit" class="btn btn-primary w-100"><i class="bi bi-check-circle me-2"></i> Check-in Peserta</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white fw-bold"><i class="bi bi-camera me-1"></i> Mode Scan QR Code</div>
                        <div class="card-body text-center d-flex flex-column justify-content-center align-items-center">
                            <div class="alert alert-warning mt-3 w-100">
                                Fitur scan QR Code melalui kamera masih dalam tahap pengembangan.
                            </div>
                            <div class="scanner-placeholder border border-primary border-3 rounded p-5 bg-light d-flex justify-content-center align-items-center" style="width: 250px; height: 250px;">
                                <i class="bi bi-qr-code text-primary" style="font-size: 5rem;"></i>
                            </div>
                            <p class="mt-3 text-muted">Arahkan kamera ke QR Code tiket peserta.</p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>