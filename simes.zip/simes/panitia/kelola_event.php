<?php
// panitia/buat_event.php

require '../config.php';

// Pastikan pengguna login
checkLogin(); 

// Pastikan role adalah panitia atau admin. 
// Ini akan menggunakan checkRole di config.php yang me-redirect ke index.php jika gagal.
checkRole(['panitia', 'admin']); 

$msg = "";
$panitia_id = $_SESSION['user_id'];
$current_page = basename(__FILE__); 

// --- Inisialisasi variabel $edit_mode (WAJIB) ---
$edit_mode = false;
// --------------------------------------------------

// --- Logika Edit/Update Event ---
if (isset($_GET['edit'])) {
    $edit_mode = true; // Di sini baru diubah menjadi true
    $event_id = clean($_GET['edit']);
    
    // Ambil data event
    $sql_event = "SELECT * FROM events WHERE id = '$event_id' AND organizer_id = '$panitia_id'";
    $result_event = mysqli_query($conn, $sql_event);
    $event_data = mysqli_fetch_assoc($result_event);

    // Ambil data tiket
    $sql_tiket = "SELECT * FROM tipe_tiket WHERE event_id = '$event_id'";
    $result_tiket = mysqli_query($conn, $sql_tiket);
    $event_data['tickets'] = mysqli_fetch_all($result_tiket, MYSQLI_ASSOC);

    if (!$event_data) {
        $msg = "<div class='alert alert-danger'>Event tidak ditemukan atau bukan milik Anda.</div>";
        $edit_mode = false;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_event'])) {
    $event_id = clean($_POST['event_id']);
    $title = clean($_POST['title']);
    $description = clean($_POST['description']);
    $event_date = clean($_POST['event_date']);
    $event_time = clean($_POST['event_time']);
    $location = clean($_POST['location']);
    $event_type = clean($_POST['event_type']);
    
    // Logika upload gambar (tidak ada di form, tapi sebaiknya disiapkan jika di masa depan ditambahkan)
    // Untuk saat ini, kita fokus pada yang ada di form.
    
    $full_datetime = $event_date . ' ' . $event_time;
    
    // 1. Update Detail Event
    // Tambahkan pengamanan status: Jika diubah, harus 'pending' lagi.
    $sql_update_event = "UPDATE events SET 
                             title = '$title', 
                             description = '$description', 
                             event_date = '$full_datetime', 
                             location = '$location', 
                             event_type = '$event_type', 
                             status = 'pending' 
                           WHERE id = '$event_id' AND organizer_id = '$panitia_id'";
    mysqli_query($conn, $sql_update_event);

    // 2. Update Tipe Tiket (Sederhana: Hapus semua lama, masukkan semua baru)
    mysqli_query($conn, "DELETE FROM tipe_tiket WHERE event_id = '$event_id'");
    
    $ticket_names = $_POST['ticket_name'];
    $ticket_prices = $_POST['ticket_price'];
    $ticket_quotas = $_POST['ticket_quota'];
    $success_tiket = true;

    for ($i = 0; $i < count($ticket_names); $i++) {
        $name = clean($ticket_names[$i]);
        $price = clean($ticket_prices[$i]);
        $quota = clean($ticket_quotas[$i]);
        
        if (!empty($name) && $quota >= 0) { // Kuota bisa 0
            $sql_tiket = "INSERT INTO tipe_tiket (event_id, nama_tiket, harga, kuota)
                          VALUES ('$event_id', '$name', '$price', '$quota')";
            if (!mysqli_query($conn, $sql_tiket)) {
                $success_tiket = false;
                break;
            }
        }
    }
    
    if ($success_tiket) {
        // Gunakan session untuk menyimpan pesan agar bisa dibaca setelah redirect
        $_SESSION['message'] = "success: Event **$title** berhasil diperbarui dan diajukan ulang. Status diubah menjadi **pending** untuk diverifikasi Admin.";
    } else {
        $_SESSION['message'] = "danger: Event berhasil diupdate, tetapi terjadi masalah saat menyimpan tipe tiket.";
    }
    
    // Redirect untuk menghindari resubmit form dan membersihkan URL
    header("Location: kelola_event.php"); 
    exit;
}

// --- Logika Hapus Event (Request Deletion) ---
if (isset($_GET['delete'])) {
    $event_id = clean($_GET['delete']);
    // Tandai sebagai 'deletion_requested'
    mysqli_query($conn, "UPDATE events SET status = 'deletion_requested' WHERE id = '$event_id' AND organizer_id = '$panitia_id'");
    
    $_SESSION['message'] = "warning: Permintaan penghapusan event telah dikirim ke Admin.";
    header("Location: kelola_event.php"); 
    exit;
}


// Ambil semua event panitia
$all_events = mysqli_query($conn, "SELECT id, title, event_date, status, location FROM events WHERE organizer_id = '$panitia_id' ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Kelola Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="absensi.php" class="<?php echo ($current_page == 'absensi.php') ? 'active' : ''; ?>">
                <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
            </a>
            <a href="verifikasi_pembayaran.php" class="<?php echo ($current_page == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
                <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
            </a>
            <a href="peserta_event.php" class="<?php echo ($current_page == 'peserta_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill me-2"></i> Daftar Peserta
            </a>
            <a href="buat_event.php" class="<?php echo ($current_page == 'buat_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
            </a>
            <a href="kelola_event.php" class="<?php echo ($current_page == 'kelola_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-list-check me-2"></i> Kelola Event Saya
            </a>
            <a href="laporan_event.php" class="<?php echo ($current_page == 'laporan_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
            </a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <?php if ($edit_mode): ?>
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #ffc107, #ff9800);">
            <h3><i class="bi bi-list-check me-2"></i> Edit Event: <?= htmlspecialchars($event_data['title']) ?></h3>
            <p class="mb-0">Perbarui detail event. Setiap perubahan akan diajukan ulang ke Admin.</p>
        </div>
        <?php else: ?>
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #198754, #20c997);">
            <h3><i class="bi bi-list-check me-2"></i> Kelola Event Saya</h3>
            <p class="mb-0">Lihat, edit, atau ajukan permintaan penghapusan untuk event yang Anda buat.</p>
        </div>
        <?php endif; ?>
        
        <?php 
        // Tampilkan pesan yang dibawa dari redirect (DELETE/UPDATE)
        if (isset($_SESSION['message'])): 
            list($type, $msg_text) = explode(': ', $_SESSION['message'], 2);
            $alert_class = ($type == 'success') ? 'alert-success' : (($type == 'warning') ? 'alert-warning' : 'alert-danger');
        ?>
            <div class="alert <?= $alert_class ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($msg_text) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php unset($_SESSION['message']); endif; ?>
        
        <?php echo $msg; // Tampilkan pesan error saat GET edit gagal ?>

        <?php if ($edit_mode): 
            $datetime = new DateTime($event_data['event_date']);
            $event_date_only = $datetime->format('Y-m-d');
            $event_time_only = $datetime->format('H:i');
        ?>
        <form method="POST">
            <input type="hidden" name="event_id" value="<?= $event_data['id'] ?>">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-warning text-dark">Ubah Detail Event</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Judul Event</label>
                        <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($event_data['title']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="description" class="form-control" rows="4" required><?= htmlspecialchars($event_data['description']) ?></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal</label>
                            <input type="date" name="event_date" class="form-control" value="<?= $event_date_only ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Waktu</label>
                            <input type="time" name="event_time" class="form-control" value="<?= $event_time_only ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Lokasi</label>
                        <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($event_data['location']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tipe Event</label>
                        <select name="event_type" class="form-select" required>
                            <?php foreach (['seminar', 'konser', 'workshop', 'pameran'] as $type): ?>
                                <option value="<?= $type ?>" <?= ($event_data['event_type'] == $type ? 'selected' : '') ?>><?= ucfirst($type) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="alert alert-info small">Gambar utama tidak dapat diubah di halaman ini. Silakan hubungi admin jika perlu.</div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    Ubah Tipe Tiket
                    <button type="button" class="btn btn-light btn-sm" id="addTicket"><i class="bi bi-plus"></i> Tambah Tiket</button>
                </div>
                <div class="card-body" id="ticketContainer">
                    <?php if (!empty($event_data['tickets'])): ?>
                        <?php foreach ($event_data['tickets'] as $ticket): ?>
                        <div class="ticket-entry row g-3 mb-3 p-3 border rounded">
                            <div class="col-md-5">
                                <label class="form-label">Nama Tiket</label>
                                <input type="text" name="ticket_name[]" class="form-control" value="<?= htmlspecialchars($ticket['nama_tiket']) ?>" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Harga</label>
                                <input type="number" name="ticket_price[]" class="form-control" value="<?= $ticket['harga'] ?>" min="0" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Kuota</label>
                                <input type="number" name="ticket_quota[]" class="form-control" value="<?= $ticket['kuota'] ?>" min="0" required>
                            </div>
                            <div class="col-md-1 d-flex align-items-end">
                                <button type="button" class="btn btn-danger w-100 remove-ticket"><i class="bi bi-x"></i></button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="ticket-entry row g-3 mb-3 p-3 border rounded">
                            <div class="col-md-5"><label class="form-label">Nama Tiket</label><input type="text" name="ticket_name[]" class="form-control" required></div>
                            <div class="col-md-3"><label class="form-label">Harga</label><input type="number" name="ticket_price[]" class="form-control" value="0" min="0" required></div>
                            <div class="col-md-3"><label class="form-label">Kuota</label><input type="number" name="ticket_quota[]" class="form-control" value="100" min="0" required></div>
                            <div class="col-md-1 d-flex align-items-end"><button type="button" class="btn btn-danger w-100 remove-ticket"><i class="bi bi-x"></i></button></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <button type="submit" name="update_event" class="btn btn-primary btn-lg me-2">Simpan Perubahan & Ajukan Ulang</button>
            <a href="kelola_event.php" class="btn btn-secondary btn-lg">Batalkan</a>
        </form>

        <?php else: ?>
        <h3 class="mt-4 mb-3 text-success">Daftar Event Anda</h3>
        <?php if (mysqli_num_rows($all_events) == 0): ?>
            <div class="alert alert-info text-center">Anda belum membuat event apapun. <a href="buat_event.php">Buat sekarang.</a></div>
        <?php else: ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <table class="table table-hover align-middle">
                        <thead class="table-light"><tr><th>Event</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($all_events)): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['title']) ?><br><small class="text-muted"><?= htmlspecialchars($row['location']) ?></small></td>
                                <td><?= date('d M Y H:i', strtotime($row['event_date'])) ?></td>
                                <td>
                                    <?php 
                                    $status_badge = ['pending' => 'warning', 'published' => 'success', 'rejected' => 'danger', 'deletion_requested' => 'info'];
                                    echo '<span class="badge bg-' . ($status_badge[$row['status']] ?? 'secondary') . '">' . ucfirst($row['status']) . '</span>';
                                    ?>
                                </td>
                                <td>
                                    <?php if ($row['status'] != 'deletion_requested'): ?>
                                        <a href="?edit=<?= $row['id'] ?>" class="btn btn-sm btn-primary me-2">Edit</a>
                                    <?php endif; ?>
                                    
                                    <?php 
                                    // Tombol Hapus: hanya tampil jika status bukan 'deletion_requested'
                                    if ($row['status'] != 'deletion_requested'): ?>
                                        <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Anda yakin ingin meminta penghapusan event ini? Admin akan memprosesnya.')">Hapus</a>
                                    <?php elseif ($row['status'] == 'deletion_requested'): ?>
                                        <button class="btn btn-sm btn-info" disabled>Menunggu Hapus</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Logika Tambah/Hapus Tiket (hanya aktif di mode edit/create)
        const setupTicketLogic = () => {
            const container = document.getElementById('ticketContainer');
            const addTicketBtn = document.getElementById('addTicket');

            if (!container || !addTicketBtn) return;

            const updateRemoveButtons = () => {
                const entries = container.querySelectorAll('.ticket-entry');
                entries.forEach(entry => {
                    const removeBtn = entry.querySelector('.remove-ticket');
                    removeBtn.onclick = function() {
                        if (container.children.length > 1) {
                            entry.remove();
                            // Optional: re-run updateRemoveButtons jika Anda ingin tombol hapus dihidupkan/dimatikan berdasarkan jumlah
                        } else {
                            alert('Minimal harus ada 1 tipe tiket.');
                        }
                    };
                });
            };

            addTicketBtn.onclick = function() {
                const firstEntry = container.querySelector('.ticket-entry');
                if (!firstEntry) return;

                const newEntry = firstEntry.cloneNode(true);
                // Reset nilai input
                newEntry.querySelectorAll('input').forEach(input => {
                    if(input.name.includes('price')) {
                        input.value = '0';
                    } else if(input.name.includes('quota')) {
                        input.value = '100';
                    } else {
                        input.value = '';
                    }
                });
                container.appendChild(newEntry);
                updateRemoveButtons(); // Pastikan tombol hapus baru juga berfungsi
            };

            // Setup awal
            updateRemoveButtons();
        };

        document.addEventListener('DOMContentLoaded', setupTicketLogic);
    </script>
</body>
</html>