<?php
// panitia/buat_event.php

require '../config.php';

// Pastikan pengguna login
checkLogin(); 

// Pastikan role adalah panitia atau admin. 
// Ini akan menggunakan checkRole di config.php yang me-redirect ke index.php jika gagal.
checkRole(['panitia', 'admin']); 

$msg = "";
$panitia_id = $_SESSION['user_id'];
$current_page = basename(__FILE__); 
// ...

// --- LOGIKA PENGAMBILAN DATA ---

// Total Omset, Tiket Terjual, dan Check-in dari semua event panitia
$sql_summary = "
    SELECT 
        SUM(CASE WHEN t.status = 'PAID' THEN t.total_bayar ELSE 0 END) as total_omset,
        SUM(CASE WHEN t.status = 'PAID' THEN t.jumlah ELSE 0 END) as total_sold,
        COUNT(DISTINCT a.transaksi_id) as total_checkin_transaksi,
        COUNT(a.id) as total_checkin_per_tiket
    FROM events e
    LEFT JOIN tipe_tiket tt ON e.id = tt.event_id
    LEFT JOIN transaksi t ON tt.id = t.tipe_tiket_id
    LEFT JOIN absensi a ON t.id = a.transaksi_id
    WHERE e.organizer_id = '$panitia_id'
";
$summary = mysqli_fetch_assoc(mysqli_query($conn, $sql_summary));

$total_omset = $summary['total_omset'] ?? 0;
$total_sold = $summary['total_sold'] ?? 0;
// Jika sistem absensi mencatat per transaksi (bukan per tiket), gunakan total_checkin_transaksi
// Jika mencatat per tiket (satu transaksi bisa memiliki 1/lebih tiket), gunakan total_checkin_per_tiket.
// Berdasarkan query absensi Anda, diasumsikan absensi mencatat per tiket yang di-scan.
// Untuk statistik absensi yang lebih bermakna (berapa orang yang hadir), total_sold dihitung sebagai total tiket.
// Kita akan menggunakan total_checkin_per_tiket untuk presentasi yang lebih akurat (berapa tiket yang di-scan).
$total_checkin = $summary['total_checkin_per_tiket'] ?? 0; 

// Data Transaksi Terbaru
$sql_transaksi = "
    SELECT 
        kode_transaksi, t.tgl_transaksi, t.total_bayar, t.status, 
        u.name, e.title, tt.nama_tiket
    FROM transaksi t
    JOIN users u ON t.user_id = u.id
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    WHERE e.organizer_id = '$panitia_id'
    ORDER BY t.tgl_transaksi DESC
    LIMIT 100
";
$transaksi = mysqli_query($conn, $sql_transaksi);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="absensi.php" class="<?php echo ($current_page == 'absensi.php') ? 'active' : ''; ?>">
                <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
            </a>
            <a href="verifikasi_pembayaran.php" class="<?php echo ($current_page == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
                <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
            </a>
            <a href="peserta_event.php" class="<?php echo ($current_page == 'peserta_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill me-2"></i> Daftar Peserta
            </a>
            <a href="buat_event.php" class="<?php echo ($current_page == 'buat_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
            </a>
            <a href="kelola_event.php" class="<?php echo ($current_page == 'kelola_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-list-check me-2"></i> Kelola Event Saya
            </a>
            <a href="laporan_event.php" class="<?php echo ($current_page == 'laporan_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
            </a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #1d3557, #457b9d);">
            <h3><i class="bi bi-bar-chart-line-fill me-2"></i> Laporan Event & Statistik</h3>
            <p class="mb-0">Ringkasan performa dan data transaksi terbaru dari semua event Anda.</p>
        </div>

        <div class="row g-4 mb-4">
            
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #198754!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-success fw-bold">Total Omset Bersih</h6>
                            <h2 class="fw-bold">Rp <?= number_format($total_omset, 0, ',', '.') ?></h2>
                        </div>
                        <div class="fs-1 text-success opacity-25"><i class="bi bi-wallet2"></i></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #0d6efd!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-primary fw-bold">Total Tiket Terjual</h6>
                            <h2 class="fw-bold"><?= $total_sold ?></h2>
                        </div>
                        <div class="fs-1 text-primary opacity-25"><i class="bi bi-ticket-fill"></i></div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #ffc107!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-warning fw-bold">Tiket Telah Check-in</h6>
                            <h2 class="fw-bold"><?= $total_checkin ?></h2>
                        </div>
                        <div class="fs-1 text-warning opacity-25"><i class="bi bi-person-check"></i></div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <?php $percent_checkin = ($total_sold > 0) ? round(($total_checkin / $total_sold) * 100) : 0; ?>
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #0dcaf0!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-info fw-bold">Rasio Absensi</h6>
                            <h2 class="fw-bold"><?= $percent_checkin ?>%</h2>
                        </div>
                        <div class="fs-1 text-info opacity-25"><i class="bi bi-graph-up"></i></div>
                    </div>
                </div>
            </div>
        </div>
        
        <h4 class="mt-4 mb-3 text-secondary">Riwayat Transaksi Terbaru</h4>
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">Daftar 100 Transaksi Terakhir</h5>
            </div>
            <div class="card-body">
                <?php if(mysqli_num_rows($transaksi) == 0): ?>
                    <p class="text-center text-muted p-3">Belum ada riwayat transaksi untuk event Anda.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped align-middle">
                            <thead><tr><th>Tanggal</th><th>Event (Tiket)</th><th>User Pembeli</th><th>Nominal</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php while($row=mysqli_fetch_assoc($transaksi)): ?>
                                <tr>
                                    <td><?= date('d/m/Y H:i', strtotime($row['tgl_transaksi'])) ?></td>
                                    <td><?= htmlspecialchars($row['title']) ?> **(<?= htmlspecialchars($row['nama_tiket']) ?>)**</td>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td class="fw-bold text-success">Rp <?= number_format($row['total_bayar']) ?></td>
                                    <td>
                                        <?php 
                                        $status_class = ['PAID' => 'success', 'PENDING' => 'warning', 'REJECTED' => 'danger'];
                                        echo '<span class="badge bg-' . ($status_class[$row['status']] ?? 'secondary') . '">' . ucfirst(strtolower($row['status'])) . '</span>';
                                        ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>