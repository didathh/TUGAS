<?php
require '../config.php';

checkLogin();
checkRole(['panitia', 'admin']);

$msg = "";
$panitia_id = $_SESSION['user_id'];
$current_page = basename(__FILE__);

// Ambil event untuk filter
$sql_events = "SELECT id, title FROM events 
               WHERE organizer_id = '$panitia_id' AND status = 'published'
               ORDER BY event_date DESC";
$result_events = mysqli_query($conn, $sql_events);

// Event terpilih (jika ada)
$selected_event = isset($_GET['filter_event']) ? $_GET['filter_event'] : '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sistem Absensi - Panitia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>

<div class="sidebar">
    <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
    <nav class="nav flex-column">
        <a href="dashboard.php" class="<?= ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
        </a>
        <a href="absensi.php" class="<?= ($current_page == 'absensi.php') ? 'active' : ''; ?>">
            <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
        </a>
        <a href="verifikasi_pembayaran.php" class="<?= ($current_page == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
            <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
        </a>
        <a href="peserta_event.php" class="<?= ($current_page == 'peserta_event.php') ? 'active' : ''; ?>">
            <i class="bi bi-people-fill me-2"></i> Daftar Peserta
        </a>
        <a href="buat_event.php" class="<?= ($current_page == 'buat_event.php') ? 'active' : ''; ?>">
            <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
        </a>
        <a href="kelola_event.php" class="<?= ($current_page == 'kelola_event.php') ? 'active' : ''; ?>">
            <i class="bi bi-list-check me-2"></i> Kelola Event Saya
        </a>
        <a href="laporan_event.php" class="<?= ($current_page == 'laporan_event.php') ? 'active' : ''; ?>">
            <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
        </a>
        <hr class="text-white">
        <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <!-- Header -->
    <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm"
         style="background: linear-gradient(135deg, #28a745, #20c997);">
        <h3><i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi</h3>
        <p class="mb-0">Pilih event dan lakukan scan QR Code untuk check-in peserta.</p>
    </div>

    <!-- Pilih Event Absensi -->
    <div class="card p-4 border-0 shadow-sm mb-4">
        <h4>Pilih Event untuk Absensi</h4>
        <form method="GET" action="absensi_scan.php">
            <div class="mb-3">
                <label class="form-label">Event Aktif</label>
                <select class="form-select" name="event_id" required>
                    <option value="">-- Pilih Event --</option>
                    <?php mysqli_data_seek($result_events, 0); ?>
                    <?php while ($event = mysqli_fetch_assoc($result_events)): ?>
                        <option value="<?= $event['id'] ?>">
                            <?= htmlspecialchars($event['title']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Mulai Absensi</button>
        </form>
    </div>

    <!-- FILTER RIWAYAT ABSENSI -->
    <div class="card p-4 border-0 shadow-sm">
        <h4 class="mb-3">Peserta yang Telah Absensi</h4>

        <form method="GET" class="row g-3 mb-4">
            <div class="col-md-6">
                <select name="filter_event" class="form-select" required>
                    <option value="">-- Filter Berdasarkan Event --</option>
                    <?php mysqli_data_seek($result_events, 0); ?>
                    <?php while ($event = mysqli_fetch_assoc($result_events)): ?>
                        <option value="<?= $event['id'] ?>"
                            <?= ($selected_event == $event['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($event['title']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-success w-100" type="submit">
                    <i class="bi bi-filter me-1"></i> Tampilkan
                </button>
            </div>
        </form>

        <?php if ($selected_event): ?>
            <?php
            $sql_absensi = "
                SELECT 
                    u.name AS nama_peserta,
                    u.email,
                    e.title AS nama_event,
                    a.check_in_time
                FROM absensi a
                JOIN transaksi t ON a.transaksi_id = t.id
                JOIN users u ON t.user_id = u.id
                JOIN events e ON t.event_id = e.id
                WHERE e.id = '$selected_event'
                ORDER BY a.check_in_time DESC
            ";
            $result_absensi = mysqli_query($conn, $sql_absensi);
            ?>

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-success">
                        <tr>
                            <th>Nama Peserta</th>
                            <th>Email</th>
                            <th>Event</th>
                            <th>Waktu Check-in</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result_absensi) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result_absensi)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                                    <td><?= htmlspecialchars($row['email']) ?></td>
                                    <td><?= htmlspecialchars($row['nama_event']) ?></td>
                                    <td><?= date('d-m-Y H:i', strtotime($row['check_in_time'])) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">
                                    Belum ada peserta yang melakukan absensi
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                Silakan pilih event untuk melihat peserta yang telah melakukan absensi.
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
