<?php
// panitia/verifikasi_pembayaran.php

require '../config.php';
checkLogin();

if ($_SESSION['role'] != 'panitia' && $_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

$panitia_id = $_SESSION['user_id'];
$current_page = basename(__FILE__);

// --- LOGIKA PEMROSESAN VERIFIKASI ---
if (isset($_POST['verify_id'])) {
    $transaksi_id = mysqli_real_escape_string($conn, $_POST['verify_id']);
    
    $sql_check = "
        SELECT t.id FROM transaksi t 
        JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
        JOIN events e ON tt.event_id = e.id
        WHERE t.id = '$transaksi_id' AND e.organizer_id = '$panitia_id' AND t.status = 'PENDING'
    ";
    
    if (mysqli_num_rows(mysqli_query($conn, $sql_check)) > 0) {
        // Query menggunakan verification_time = NOW() (Karena Anda sudah menjalankan ALTER TABLE)
        $sql_update = "UPDATE transaksi SET status = 'PAID', verification_time = NOW() WHERE id = '$transaksi_id'";
        
        if (mysqli_query($conn, $sql_update)) {
            $message = "success: Transaksi ID #{$transaksi_id} berhasil diverifikasi (PAID).";
        } else {
            // Tambahkan error MySQL agar mudah didiagnosa
            $message = "error: Gagal memperbarui status transaksi. Error DB: " . mysqli_error($conn);
        }
    } else {
        $message = "error: Transaksi tidak valid atau sudah diverifikasi.";
    }
        
    $_SESSION['message'] = $message;
    header("Location: verifikasi_pembayaran.php");
    exit;
}

// --- LOGIKA TOLAK TRANSAKSI ---
if (isset($_POST['reject_id'])) {
    $transaksi_id = mysqli_real_escape_string($conn, $_POST['reject_id']);

    $sql_check = "
        SELECT t.id FROM transaksi t
        JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
        JOIN events e ON tt.event_id = e.id
        WHERE t.id = '$transaksi_id'
        AND e.organizer_id = '$panitia_id'
        AND t.status = 'PENDING'
    ";

    if (mysqli_num_rows(mysqli_query($conn, $sql_check)) > 0) {
        $sql_reject = "
            UPDATE transaksi 
            SET status = 'REJECTED', verification_time = NOW()
            WHERE id = '$transaksi_id'
        ";

        if (mysqli_query($conn, $sql_reject)) {
            $_SESSION['message'] = "success: Transaksi ID #{$transaksi_id} berhasil DITOLAK.";
        } else {
            $_SESSION['message'] = "error: Gagal menolak transaksi. Error DB: " . mysqli_error($conn);
        }
    } else {
        $_SESSION['message'] = "error: Transaksi tidak valid atau tidak dapat ditolak.";
    }

    header("Location: verifikasi_pembayaran.php");
    exit;
}


// --- LOGIKA PENGAMBILAN DATA PENDING ---
$sql_pending = "
    SELECT 
        t.id AS transaksi_id,
        t.tgl_transaksi, 
        t.total_bayar,
        t.bukti_transfer,
        e.title AS nama_event,
        u.name AS nama_peserta
    FROM transaksi t
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    JOIN users u ON t.user_id = u.id
    WHERE e.organizer_id = '$panitia_id' AND t.status = 'PENDING'
    ORDER BY t.tgl_transaksi ASC
";
$result_pending = mysqli_query($conn, $sql_pending);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Verifikasi Pembayaran - Panitia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES PANITIA</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a href="absensi.php" class="<?php echo ($current_page == 'absensi.php') ? 'active' : ''; ?>">
                <i class="bi bi-qr-code-scan me-2"></i> Sistem Absensi
            </a>
            <a href="verifikasi_pembayaran.php" class="<?php echo ($current_page == 'verifikasi_pembayaran.php') ? 'active' : ''; ?>">
                <i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran
            </a>
            <a href="peserta_event.php" class="<?php echo ($current_page == 'peserta_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill me-2"></i> Daftar Peserta
            </a>
            <a href="buat_event.php" class="<?php echo ($current_page == 'buat_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-plus-circle me-2"></i> Buat Event Baru
            </a>
            <a href="kelola_event.php" class="<?php echo ($current_page == 'kelola_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-list-check me-2"></i> Kelola Event Saya
            </a>
            <a href="laporan_event.php" class="<?php echo ($current_page == 'laporan_event.php') ? 'active' : ''; ?>">
                <i class="bi bi-bar-chart-line-fill me-2"></i> Laporan & Statistik
            </a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>
    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #0d6efd, #0dcaf0);">
            <h3><i class="fas fa-money-check-alt me-2"></i> Verifikasi Pembayaran</h3>
            <p class="mb-0">Daftar transaksi yang perlu Anda verifikasi buktinya.</p>
        </div>
        
        <?php if (isset($_SESSION['message'])): ?>
            <?php 
                list($type, $msg) = explode(': ', $_SESSION['message'], 2);
                $alert_class = ($type == 'success') ? 'alert-success' : 'alert-danger';
            ?>
            <div class="alert <?= $alert_class ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($msg) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <div class="card border-0 shadow-sm mt-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Transaksi Menunggu Verifikasi (PENDING)</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php if (mysqli_num_rows($result_pending) > 0): ?>
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID Transaksi</th>
                                    <th>Nama Peserta</th>
                                    <th>Event</th>
                                    <th>Total Bayar</th>
                                    <th>Tgl Transaksi</th>
                                    <th>Bukti Transfer</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_assoc($result_pending)): ?>
                                <tr>
                                    <td>#<?= htmlspecialchars($row['transaksi_id']) ?></td>
                                    <td><?= htmlspecialchars($row['nama_peserta']) ?></td>
                                    <td><?= htmlspecialchars($row['nama_event']) ?></td>
                                    <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                    <td>
                                        <?= date('d M Y H:i', strtotime($row['tgl_transaksi'])) ?> 
                                    </td>
                                    <td>
                                        <?php if (!empty($row['bukti_transfer'])): ?>
                                            <a href="<?= $base_url ?>uploads/bukti_transfer/<?= htmlspecialchars($row['bukti_transfer']) ?>" target="_blank" class="btn btn-sm btn-info text-white">Lihat Bukti</a>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <!-- VERIFIKASI -->
                                            <form method="POST"
                                                onsubmit="return confirm('Yakin ingin MEMVERIFIKASI transaksi #<?= htmlspecialchars($row['transaksi_id']) ?>?');">
                                                <input type="hidden" name="verify_id" value="<?= htmlspecialchars($row['transaksi_id']) ?>">
                                                <button type="submit" class="btn btn-sm btn-success">
                                                    <i class="fas fa-check me-1"></i> Verifikasi
                                                </button>
                                            </form>

                                            <!-- TOLAK -->
                                            <form method="POST"
                                                onsubmit="return confirm('Yakin ingin MENOLAK transaksi #<?= htmlspecialchars($row['transaksi_id']) ?>?');">
                                                <input type="hidden" name="reject_id" value="<?= htmlspecialchars($row['transaksi_id']) ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-times me-1"></i> Tolak
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-info text-center mb-0">
                            Tidak ada transaksi dengan status PENDING yang membutuhkan verifikasi saat ini.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>