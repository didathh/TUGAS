<?php
// index.php

require 'config.php'; 
// Tidak perlu checkLogin() karena ini halaman publik

// FIX: Menggunakan kolom 'image' sesuai DB
$events = mysqli_query($conn, "SELECT id, title, event_date, location, image FROM events WHERE status = 'published' ORDER BY event_date ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>SIMES - Event Ticketing System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
    <style>
        .event-card { transition: transform 0.2s; }
        .event-card:hover { transform: translateY(-5px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .hero { background: linear-gradient(135deg, #0d6efd, #0dcaf0); color: white; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">SIMES EVENT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= ($_SESSION['role'] == 'admin') ? 'admin/dashboard.php' : (($_SESSION['role'] == 'panitia') ? 'panitia/dashboard.php' : 'peserta/dashboard.php') ?>">
                                <i class="bi bi-person-circle me-1"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link btn btn-warning text-dark ms-2" href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero py-5 mb-5">
        <div class="container text-center">
            <h1 class="display-4 fw-bold">Temukan Event Hebatmu</h1>
            <p class="lead">Beli tiket event favoritmu dengan mudah dan cepat di SIMES.</p>
        </div>
    </div>

    <div class="container mb-5">
        <h3 class="mb-4 text-primary fw-bold text-center">Event yang Sedang Berlangsung</h3>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php if (mysqli_num_rows($events) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($events)): 
                    $min_price = getEventTicketPrice($row['id']); 
                ?>
                    <div class="col">
                        <div class="card event-card h-100 border-0 shadow-sm">
                            <img src="<?= $base_url ?>uploads/event_images/<?= htmlspecialchars($row['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($row['title']) ?>" style="height: 200px; object-fit: cover;">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title text-primary fw-bold"><?= htmlspecialchars($row['title']) ?></h5>
                                <p class="card-text mb-1"><i class="bi bi-calendar me-1"></i> <?= date('d M Y', strtotime($row['event_date'])) ?></p>
                                <p class="card-text mb-3 text-muted"><i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($row['location']) ?></p>
                                <p class="card-text fw-bold text-success mt-auto"><?= $min_price == 0 ? 'GRATIS' : formatRupiah($min_price) ?></p> 
                                <a href="event_detail.php?id=<?= $row['id'] ?>" class="btn btn-primary mt-2">Lihat Detail & Beli</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12"><div class="alert alert-info text-center">Belum ada event yang dipublikasikan saat ini.</div></div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>