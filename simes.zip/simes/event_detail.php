<?php
// event_detail.php

require 'config.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$event_id = clean($_GET['id']);
$user_id = isLoggedIn() ? $_SESSION['user_id'] : null;
$msg = '';

// Ambil data Event
$sql_event = "SELECT e.*, u.name as organizer_name FROM events e JOIN users u ON e.organizer_id = u.id WHERE e.id = '$event_id' AND e.status = 'published'";
$result_event = mysqli_query($conn, $sql_event);
$event = mysqli_fetch_assoc($result_event);

if (!$event) {
    echo "<div class='alert alert-danger'>Event tidak ditemukan atau belum dipublikasikan.</div>";
    exit;
}

// Ambil Tipe Tiket
$sql_tickets = "SELECT * FROM tipe_tiket WHERE event_id = '$event_id' AND kuota > 0 ORDER BY harga ASC";
$tickets = mysqli_query($conn, $sql_tickets);

// Logika Pembelian Tiket
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_ticket'])) {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
    
    $tipe_tiket_id = clean($_POST['tipe_tiket_id']);
    $jumlah = clean($_POST['jumlah']);

    $ticket_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tipe_tiket WHERE id = '$tipe_tiket_id'"));
    
    if ($jumlah <= 0) {
        $msg = "<div class='alert alert-danger'>Jumlah tiket minimal 1.</div>";
    } elseif ($jumlah > $ticket_info['kuota']) {
        $msg = "<div class='alert alert-danger'>Jumlah yang dibeli melebihi kuota yang tersedia ({$ticket_info['kuota']}).</div>";
    } else {
        $total_bayar = $ticket_info['harga'] * $jumlah;
        $kode_transaksi = 'TRX' . time() . rand(100, 999);
        
        // FIX: Menambahkan kolom 'tgl_transaksi'
        $sql_transaksi = "INSERT INTO transaksi (kode_transaksi, user_id, tipe_tiket_id, jumlah, total_bayar, status, tgl_transaksi)
                          VALUES ('$kode_transaksi', '$user_id', '$tipe_tiket_id', '$jumlah', '$total_bayar', 'PENDING', NOW())";
        
        if (mysqli_query($conn, $sql_transaksi)) {
            // Kurangi kuota segera (Pre-booking)
            mysqli_query($conn, "UPDATE tipe_tiket SET kuota = kuota - $jumlah WHERE id = '$tipe_tiket_id'");
            
            header("Location: peserta/payment.php?trx_id=" . $kode_transaksi);
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Gagal memproses transaksi.</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($event['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">SIMES EVENT</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= ($_SESSION['role'] == 'admin') ? 'admin/dashboard.php' : (($_SESSION['role'] == 'panitia') ? 'panitia/dashboard.php' : 'peserta/dashboard.php') ?>"><i class="bi bi-person-circle"></i> Dashboard</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link btn btn-warning text-dark ms-2" href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container my-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($event['title']) ?></li>
            </ol>
        </nav>

        <?= $msg ?>

        <div class="row g-5">
            <div class="col-md-8">
                <img src="<?= $base_url ?>uploads/event_images/<?= htmlspecialchars($event['image']) ?>" class="img-fluid rounded shadow-sm mb-4" alt="<?= htmlspecialchars($event['title']) ?>">
                
                <h1 class="text-primary fw-bold mb-3"><?= htmlspecialchars($event['title']) ?></h1>
                
                <div class="d-flex flex-wrap gap-4 mb-4 text-muted">
                    <span><i class="bi bi-calendar-event me-1"></i> <?= date('d F Y', strtotime($event['event_date'])) ?></span>
                    <span><i class="bi bi-clock me-1"></i> <?= date('H:i', strtotime($event['event_date'])) ?> WIB</span>
                    <span><i class="bi bi-geo-alt me-1"></i> <?= htmlspecialchars($event['location']) ?></span>
                    <span><i class="bi bi-person-badge me-1"></i> Penyelenggara: <?= htmlspecialchars($event['organizer_name']) ?></span>
                </div>

                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <h4 class="text-primary border-bottom pb-2 mb-3">Deskripsi Event</h4>
                        <p style="white-space: pre-wrap;"><?= htmlspecialchars($event['description']) ?></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card sticky-top shadow-lg border-0" style="top: 20px;">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Beli Tiket Sekarang</h5>
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($tickets) == 0): ?>
                            <div class="alert alert-warning text-center">Tiket belum tersedia atau habis.</div>
                        <?php else: ?>
                            <form method="POST">
                                <input type="hidden" name="event_id" value="<?= $event_id ?>">
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Pilih Tipe Tiket</label>
                                    <select name="tipe_tiket_id" class="form-select" required>
                                        <option value="">-- Pilih Tipe --</option>
                                        <?php 
                                        mysqli_data_seek($tickets, 0); // Reset pointer
                                        while ($ticket = mysqli_fetch_assoc($tickets)): 
                                            // FIX: Gunakan formatRupiah()
                                            $price_display = $ticket['harga'] > 0 ? formatRupiah($ticket['harga']) : 'Gratis';
                                            $kuota_display = $ticket['kuota'] > 0 ? "({$ticket['kuota']} tersedia)" : "(Habis)";
                                        ?>
                                            <option value="<?= $ticket['id'] ?>" 
                                                data-price="<?= $ticket['harga'] ?>"
                                                <?= $ticket['kuota'] <= 0 ? 'disabled' : '' ?>>
                                                <?= htmlspecialchars($ticket['nama_tiket']) ?> - <?= $price_display ?> <?= $kuota_display ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Jumlah Tiket</label>
                                    <input type="number" name="jumlah" id="jumlah_tiket" class="form-control" value="1" min="1" required>
                                </div>
                                
                                <div class="mb-3 p-3 bg-light rounded">
                                    <h6 class="mb-0 text-dark">Total Pembayaran: <span id="total_bayar_display" class="fw-bold text-success float-end"><?= formatRupiah(0) ?></span></h6>
                                </div>
                                
                                <button type="submit" name="buy_ticket" class="btn btn-success btn-lg w-100" <?= !isLoggedIn() ? 'disabled' : '' ?>>
                                    <i class="bi bi-cart-fill me-1"></i> Beli Sekarang
                                </button>
                                <?php if (!isLoggedIn()): ?>
                                    <p class="text-center mt-3 small text-danger">Anda harus <a href="login.php">Login</a> untuk membeli tiket.</p>
                                <?php endif; ?>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Logika Live Update Harga
        document.addEventListener('DOMContentLoaded', function() {
            const selectTiket = document.querySelector('select[name="tipe_tiket_id"]');
            const inputJumlah = document.getElementById('jumlah_tiket');
            const totalDisplay = document.getElementById('total_bayar_display');

            function formatRupiahJS(number) {
                return 'Rp ' + new Intl.NumberFormat('id-ID').format(number);
            }

            function updateTotalPrice() {
                const selectedOption = selectTiket.options[selectTiket.selectedIndex];
                const price = parseFloat(selectedOption.getAttribute('data-price') || 0);
                const quantity = parseInt(inputJumlah.value) || 0;
                const total = price * quantity;
                
                totalDisplay.textContent = formatRupiahJS(total);
            }

            // Atur kuota max berdasarkan tiket yang dipilih (Fitur Tambahan)
            selectTiket.addEventListener('change', function() {
                // Reset kuota max
                inputJumlah.removeAttribute('max');

                const selectedOption = this.options[this.selectedIndex];
                const text = selectedOption.text;
                
                // Cari kuota yang tersedia dalam kurung
                const match = text.match(/\((\d+) tersedia\)/);
                if (match) {
                    const availableQuota = parseInt(match[1]);
                    inputJumlah.setAttribute('max', availableQuota);
                    // Jika jumlah input melebihi kuota, set ke kuota maksimal
                    if (parseInt(inputJumlah.value) > availableQuota) {
                        inputJumlah.value = availableQuota;
                    }
                }
                updateTotalPrice();
            });

            inputJumlah.addEventListener('input', updateTotalPrice);
            
            // Panggil saat load pertama
            updateTotalPrice();
        });
    </script>
</body>
</html>