<?php
require 'config.php';
checkLogin();

if (isset($_POST['event_id'])) {
    $event_id = clean($_POST['event_id']);
    $user_id = $_SESSION['user_id'];
    
    // Pastikan event ada dan harganya > 0
    $q_event = mysqli_query($conn, "SELECT e.title, e.price, u.phone 
                                    FROM events e 
                                    JOIN users u ON e.organizer_id = u.id 
                                    WHERE e.id = '$event_id'");
    
    if (mysqli_num_rows($q_event) == 0) {
        die("Event tidak ditemukan.");
    }

    $d_event = mysqli_fetch_assoc($q_event);
    
    $trx_code = "TRX-" . time() . rand(100,999); // Kode unik transaksi
    
    // 1. Simpan Transaksi ke database (Status Pending)
    $sql = "INSERT INTO transaksi (user_id, event_id, transaction_code, status) 
            VALUES ('$user_id', '$event_id', '$trx_code', 'pending')";
    
    if (mysqli_query($conn, $sql)) {
        
        // 2. Persiapan data untuk WhatsApp
        $panitia_phone = $d_event['phone']; 
        
        // Cek dan format nomor HP (Ganti 08xxx menjadi 628xxx jika perlu di logic ini)
        if (substr($panitia_phone, 0, 1) == '0') {
            $panitia_phone = '62' . substr($panitia_phone, 1);
        }

        $pesan = "Halo Panitia, saya *{$_SESSION['name']}* ingin konfirmasi pembayaran untuk event: *" . $d_event['title'] . "*\nKode Transaksi: *" . $trx_code . "*\nTotal Biaya: *Rp " . number_format($d_event['price'], 0, ',', '.') . "*\n\n(Mohon sertakan bukti transfer dan tunggu verifikasi untuk tiket Anda)";
        
        // 3. Direct ke WhatsApp
        $wa_url = "https://wa.me/$panitia_phone?text=" . urlencode($pesan);
        
        // Redirect ke WA.
        header("Location: $wa_url");
        exit;
    } else {
        die("Gagal menyimpan transaksi.");
    }
} else {
    header("Location: index.php");
    exit;
}
?>