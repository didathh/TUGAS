-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 18 Des 2025 pada 14.31
-- Versi server: 8.0.30
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Basis data: `simes_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE `absensi` (
  `id` int NOT NULL,
  `transaksi_id` int NOT NULL,
  `check_in_time` datetime NOT NULL,
  `panitia_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `events`
--

CREATE TABLE `events` (
  `id` int NOT NULL,
  `organizer_id` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `event_date` date DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `capacity` int DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('pending','published','rejected','deletion_requested') DEFAULT 'published',
  `event_type` varchar(50) NOT NULL,
  `wa_panitia` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `events`
--

INSERT INTO `events` (`id`, `organizer_id`, `title`, `description`, `event_date`, `location`, `price`, `capacity`, `image`, `status`, `event_type`, `wa_panitia`) VALUES
(16, 14, 'lomba coding', 'juara 1 1.000.000', '2025-12-20', 'kampus 1', NULL, NULL, '1765781322_hindia.jpg', 'pending', 'workshop', '6282241105099');

-- --------------------------------------------------------

--
-- Struktur dari tabel `panitia_requests`
--

CREATE TABLE `panitia_requests` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `motivasi` text,
  `reason` text,
  `status` enum('pending','approved','rejected') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `panitia_requests`
--

INSERT INTO `panitia_requests` (`id`, `user_id`, `motivasi`, `reason`, `status`) VALUES
(6, 14, NULL, '123', 'approved');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tipe_tiket`
--

CREATE TABLE `tipe_tiket` (
  `id` int NOT NULL,
  `event_id` int NOT NULL,
  `nama_tiket` varchar(100) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `kuota` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tipe_tiket`
--

INSERT INTO `tipe_tiket` (`id`, `event_id`, `nama_tiket`, `harga`, `kuota`) VALUES
(26, 16, 'Biasa', 50000.00, 100);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `event_id` int DEFAULT NULL,
  `tipe_tiket_id` int DEFAULT NULL,
  `kode_transaksi` varchar(50) NOT NULL,
  `jumlah` int DEFAULT '1',
  `total_bayar` decimal(10,2) DEFAULT '0.00',
  `bukti_transfer` varchar(255) DEFAULT NULL,
  `status` enum('PENDING','PAID','REJECTED','EXPIRED','CHECKED_IN') NOT NULL DEFAULT 'PENDING',
  `tgl_transaksi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verification_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('user','peserta','panitia','admin') NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `phone`, `created_at`) VALUES
(1, 'Super Admin SIMES', 'admin@simes.com', '$2y$10$4iRu5JOOFhIlhAFTZxgMuebOCpgBLtc3/Idzk.Vlo8XCCCDUziv4.', 'admin', '081211223344', '2025-12-09 16:00:31'),
(13, 'member asal gorontalo', 'peserta@simes.com', '$2y$10$NDwI0SJjSdcUEq8tFgut2.fsS2HnHrBbiJj9LiHnyay.K/zJzzcgG', 'user', '085342121383', '2025-12-14 17:02:35'),
(14, 'panitia', 'panitia@simes.com', '$2y$10$LAq7UFj2iP4aHtxjvaR/BuZkY.KbOoPO5Icw/slImI7ST9jEz1bmO', 'panitia', NULL, '2025-12-14 17:02:53');

--
-- Indeks untuk tabel yang dibuang
--

--
-- Indeks untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaksi_id` (`transaksi_id`),
  ADD KEY `panitia_id` (`panitia_id`);

--
-- Indeks untuk tabel `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organizer_id` (`organizer_id`);

--
-- Indeks untuk tabel `panitia_requests`
--
ALTER TABLE `panitia_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `tipe_tiket`
--
ALTER TABLE `tipe_tiket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_transaksi` (`kode_transaksi`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `tipe_tiket_id` (`tipe_tiket_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `events`
--
ALTER TABLE `events`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `panitia_requests`
--
ALTER TABLE `panitia_requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `tipe_tiket`
--
ALTER TABLE `tipe_tiket`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD CONSTRAINT `absensi_ibfk_1` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `absensi_ibfk_2` FOREIGN KEY (`panitia_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT;

--
-- Ketidakleluasaan untuk tabel `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `panitia_requests`
--
ALTER TABLE `panitia_requests`
  ADD CONSTRAINT `panitia_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tipe_tiket`
--
ALTER TABLE `tipe_tiket`
  ADD CONSTRAINT `tipe_tiket_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_event_fk` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`tipe_tiket_id`) REFERENCES `tipe_tiket` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaksi_tiket_fk` FOREIGN KEY (`tipe_tiket_id`) REFERENCES `tipe_tiket` (`id`) ON DELETE RESTRICT,
  ADD CONSTRAINT `transaksi_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
