<?php
// peserta/my_tickets.php

require '../config.php';

// Pastikan hanya user & panitia yang login
checkRole(['user', 'panitia']);

// Jika panitia masuk halaman peserta → arahkan ke dashboard panitia
if ($_SESSION['role'] !== 'user') {
    header("Location: ../panitia/dashboard.php");
    exit;
}

$page_title = 'Tiket Saya';
$user_id = $_SESSION['user_id'];
$msg = '';

// ================================
// LOGIKA FILTER & PENCARIAN
// ================================
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? 'all';

// Kondisi dasar
$query_where = "t.user_id = '$user_id'";

// Filter status
if ($status_filter !== 'all') {
    $status_filter_safe = clean($status_filter);
    $query_where .= " AND t.status = '$status_filter_safe'";
}

// Pencarian judul event
if (!empty($search)) {
    $search_safe = "%" . clean($search) . "%";
    $query_where .= " AND e.title LIKE '$search_safe'";
}

// ================================
// AMBIL DATA TRANSAKSI / TIKET
// ================================
$sql_tickets = "
    SELECT 
        t.id,
        kode_transaksi,
        t.jumlah,
        t.total_bayar,
        t.status,
        t.tgl_transaksi,
        e.title AS event_title,
        e.event_date,
        e.location,
        e.wa_panitia,
        tt.nama_tiket,
        tt.harga
    FROM transaksi t
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    WHERE $query_where
    ORDER BY t.tgl_transaksi DESC
";

$result_tickets = mysqli_query($conn, $sql_tickets);

// ================================
// HELPER BADGE STATUS
// ================================
function get_status_badge($status)
{
    $map = [
        'PAID'     => 'success',
        'PENDING'  => 'warning',
        'REJECTED' => 'danger',
        'EXPIRED'  => 'secondary'
    ];

    $class = $map[$status] ?? 'secondary';
    return '<span class="badge bg-' . $class . '">' . ucfirst(strtolower($status)) . '</span>';
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main-content">

    <!-- HEADER -->
    <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm"
         style="background: linear-gradient(135deg, #20c997, #198754);">
        <h3 class="mb-1">
            <i class="bi bi-ticket-fill me-2"></i> Tiket Saya
        </h3>
        <p class="mb-0">Daftar seluruh transaksi dan tiket yang Anda miliki.</p>
    </div>

    <!-- FILTER -->
    <div class="card border-0 shadow-sm mb-4 p-3">
        <form method="GET" class="row g-3 align-items-center">
            <div class="col-md-5">
                <input type="text"
                       class="form-control"
                       name="search"
                       placeholder="Cari judul event..."
                       value="<?= htmlspecialchars($search) ?>">
            </div>

            <div class="col-md-4">
                <select class="form-select" name="status">
                    <option value="all" <?= $status_filter == 'all' ? 'selected' : '' ?>>Semua Status</option>
                    <option value="PENDING" <?= $status_filter == 'PENDING' ? 'selected' : '' ?>>PENDING</option>
                    <option value="PAID" <?= $status_filter == 'PAID' ? 'selected' : '' ?>>PAID</option>
                    <option value="REJECTED" <?= $status_filter == 'REJECTED' ? 'selected' : '' ?>>REJECTED</option>
                    <option value="EXPIRED" <?= $status_filter == 'EXPIRED' ? 'selected' : '' ?>>EXPIRED</option>
                </select>
            </div>

            <div class="col-md-3 d-flex gap-2">
                <button class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i> Filter
                </button>
                <a href="my_tickets.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-clockwise"></i>
                </a>
            </div>
        </form>
    </div>

    <!-- TABEL TIKET -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">

            <?php if (mysqli_num_rows($result_tickets) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                    <tr>
                        <th>Event</th>
                        <th>ID Transaksi</th>
                        <th>Total Bayar</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php while ($trx = mysqli_fetch_assoc($result_tickets)): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($trx['event_title']) ?></strong><br>
                                <small class="text-muted">
                                    <i class="bi bi-calendar-event me-1"></i>
                                    <?= date('d M Y', strtotime($trx['event_date'])) ?>
                                </small><br>
                                <small class="text-secondary">
                                    <?= htmlspecialchars($trx['nama_tiket']) ?> (x<?= $trx['jumlah'] ?>)
                                </small>
                            </td>

                            <td>
                                <small class="text-muted">#<?= htmlspecialchars($trx['kode_transaksi']) ?></small>
                            </td>

                            <td>
                                <span class="fw-bold text-success">
                                    Rp <?= number_format($trx['total_bayar'], 0, ',', '.') ?>
                                </span>
                            </td>

                            <td><?= get_status_badge($trx['status']) ?></td>
                            <td>
                            <?php
                            $status = strtoupper(trim($trx['status']));
                            ?>

                            <?php if ($status === 'PAID'): ?>

                                <a href="../cetak_tiket.php?id=<?= $trx['id'] ?>"
                                target="_blank"
                                class="btn btn-sm btn-info text-white">
                                    <i class="bi bi-printer me-1"></i> Cetak Tiket
                                </a>

                            <?php elseif ($status === 'PENDING'): ?>

                                <?php if (!empty(trim($trx['wa_panitia']))):?>
                                    <button class="btn btn-sm btn-warning"
                                            data-bs-toggle="modal"
                                            data-bs-target="#paymentModal"
                                            data-trx="<?= $trx['kode_transaksi'] ?>"
                                            data-event="<?= htmlspecialchars($trx['event_title']) ?>"
                                            data-tiket="<?= htmlspecialchars($trx['nama_tiket']) ?>"
                                            data-total="<?= formatRupiah($trx['total_bayar']) ?>"
                                            data-wa="<?= $trx['wa_panitia'] ?>">
                                        <i class="bi bi-cash me-1"></i> Konfirmasi Bayar
                                    </button>
                                <?php else: ?>
                                    <span class="text-danger small">
                                        Kontak panitia belum tersedia
                                    </span>
                                <?php endif; ?>

                            <?php elseif ($status === 'REJECTED'): ?>

                                <span class="text-danger small">Pembayaran ditolak</span>

                            <?php elseif ($status === 'EXPIRED'): ?>

                                <span class="text-secondary small">Transaksi kedaluwarsa</span>

                            <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>

                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <p class="text-center text-muted p-4">
                    Tidak ada transaksi yang ditemukan.
                </p>
            <?php endif; ?>

        </div>
    </div>
</div>
<div class="modal fade" id="paymentModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header bg-warning">
        <h5 class="modal-title fw-bold">Detail Pembayaran</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <p><strong>ID Transaksi:</strong> <span id="m_trx"></span></p>
        <p><strong>Event:</strong> <span id="m_event"></span></p>
        <p><strong>Tiket:</strong> <span id="m_tiket"></span></p>
        <p class="fs-5 fw-bold text-success">
            Total Bayar: <span id="m_total"></span>
        </p>

        <div class="alert alert-info small">
            Silakan hubungi panitia melalui WhatsApp untuk mengirim bukti pembayaran
            dan melakukan verifikasi.
        </div>
      </div>

      <div class="modal-footer">
        <a href="#" target="_blank" id="btnWA"
           class="btn btn-success w-100">
           <i class="bi bi-whatsapp me-1"></i> Hubungi Panitia
        </a>
      </div>

    </div>
  </div>
</div>
<script>
const paymentModal = document.getElementById('paymentModal');

paymentModal.addEventListener('show.bs.modal', function (event) {
    const button = event.relatedTarget;

    const trx   = button.getAttribute('data-trx');
    const eventName = button.getAttribute('data-event');
    const tiket = button.getAttribute('data-tiket');
    const total = button.getAttribute('data-total');
    const wa    = button.getAttribute('data-wa');

    document.getElementById('m_trx').textContent   = trx;
    document.getElementById('m_event').textContent = eventName;
    document.getElementById('m_tiket').textContent = tiket;
    document.getElementById('m_total').textContent = total;

    const pesan = encodeURIComponent(
        `Halo Panitia Event ${eventName},\n\n` +
        `Saya ingin konfirmasi pembayaran tiket:\n\n` +
        `ID Transaksi: ${trx}\n` +
        `Tiket: ${tiket}\n` +
        `Total Bayar: ${total}\n\n` +
        `Terima kasih.`
    );

    document.getElementById('btnWA').href =
        `https://wa.me/${wa}?text=${pesan}`;
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
