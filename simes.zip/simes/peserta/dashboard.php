<?php
// user/dashboard.php

require '../config.php';
// Pastikan file config.php memiliki fungsi checkRole(['user', 'panitia']) yang berfungsi
// dan fungsi checkLogin() atau checkRole() tersedia.

// Logika awal untuk memastikan akses
// Catatan: checkRole(['user', 'panitia']) harus didefinisikan di config.php
if (!function_exists('checkRole')) {
    // Fallback jika checkRole tidak ada
    function checkRole($roles) {
        if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $roles)) {
            header("Location: ../login.php");
            exit;
        }
    }
}
checkRole(['user', 'panitia']);

if ($_SESSION['role'] != 'user') {
    // Jika role sudah panitia (sudah disetujui), arahkan ke dashboard panitia
    header("Location: ../panitia/dashboard.php");
    exit;
}

$page_title = 'dashboard';
$user_id = $_SESSION['user_id'];

// --- LOGIKA STATISTIK user (Kode Anda) ---
// 1. Total Tiket Aktif (Paid)
$sql_paid = "SELECT COALESCE(SUM(jumlah), 0) as total FROM transaksi WHERE user_id = '$user_id' AND status = 'PAID'";
$total_paid = mysqli_fetch_assoc(mysqli_query($conn, $sql_paid))['total'] ?? 0;

// 2. Total Transaksi Pending
$sql_pending = "SELECT COUNT(id) as total FROM transaksi WHERE user_id = '$user_id' AND status = 'PENDING'";
$total_pending = mysqli_fetch_assoc(mysqli_query($conn, $sql_pending))['total'] ?? 0;

// 3. Total Event yang Dihadiri (Unique event IDs from PAID transaksi)
$sql_events = "
    SELECT COUNT(DISTINCT e.id) as total 
    FROM transaksi t
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    WHERE t.user_id = '$user_id' AND t.status = 'PAID'
";
$total_events = mysqli_fetch_assoc(mysqli_query($conn, $sql_events))['total'] ?? 0;


// --- LOGIKA FILTER & PENCARIAN EVENT TERSEDIA (FITUR BARU) ---
$search_event = $_GET['search_event'] ?? '';
$event_type_filter = $_GET['event_type'] ?? 'all';
$query_event_where = "status = 'published'"; // Hanya tampilkan event yang sudah dipublikasi

// Filter berdasarkan Jenis Event
if ($event_type_filter !== 'all' && !empty($event_type_filter)) {
    $event_type_safe = clean($event_type_filter);
    $query_event_where .= " AND event_type = '$event_type_safe'";
}

// Pencarian Judul Event
if (!empty($search_event)) {
    $search_safe = "%" . clean($search_event) . "%";
    $query_event_where .= " AND title LIKE '$search_safe'";
}

// Mengambil semua event yang tersedia (dan belum lewat tanggalnya)
$sql_available_events = "
    SELECT 
        id, title, event_date, location, price, image, event_type
    FROM events 
    WHERE $query_event_where AND event_date >= CURDATE()
    ORDER BY event_date ASC
";
$result_available_events = mysqli_query($conn, $sql_available_events);

// Ambil semua jenis event unik untuk dropdown filter
$sql_event_types = "SELECT DISTINCT event_type FROM events WHERE event_type IS NOT NULL AND status = 'published'";
$result_event_types = mysqli_query($conn, $sql_event_types);
$event_types = [];
while ($row = mysqli_fetch_assoc($result_event_types)) {
    if (!empty($row['event_type'])) {
        $event_types[] = $row['event_type'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Peserta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
    <style>
        /* CSS Tambahan untuk kartu event */
        .event-card {
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
            height: 100%;
        }
        .event-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15)!important;
        }
        .event-card-img {
            height: 150px;
            object-fit: cover;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php 
    // Diasumsikan file sidebar.php sudah ada dan mengandung navigasi
    include 'sidebar.php'; 
    ?>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #0d6efd, #0dcaf0);">
            <h3>Halo, <?= htmlspecialchars($_SESSION['name']) ?>!</h3>
            <p class="mb-0">Selamat datang di panel Peserta Anda. Lihat dan kelola tiket Anda.</p>
        </div>

        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #198754!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted">Tiket Aktif (PAID)</h6>
                            <h2 class="fw-bold text-success"><?= $total_paid ?></h2>
                        </div>
                        <div class="fs-1 text-success opacity-25"><i class="bi bi-ticket"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #ffc107!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted">Transaksi Pending</h6>
                            <h2 class="fw-bold text-warning"><?= $total_pending ?></h2>
                        </div>
                        <div class="fs-1 text-warning opacity-25"><i class="bi bi-hourglass-split"></i></div>
                    </div>
                    <a href="my_tickets.php?status=PENDING" class="small text-decoration-none mt-2 d-block text-warning">Konfirmasi Pembayaran &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #0d6efd!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted">Total Event Diikuti</h6>
                            <h2 class="fw-bold text-primary"><?= $total_events ?></h2>
                        </div>
                        <div class="fs-1 text-primary opacity-25"><i class="bi bi-calendar-event"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <h3 class="mb-3 text-primary fw-bold">Tiket Terbaru Anda</h3>
        <?php 
        $sql_latest = "
            SELECT kode_transaksi, t.tgl_transaksi, t.total_bayar, t.status, e.title, tt.nama_tiket, t.id as transaksi_pk
            FROM transaksi t
            JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
            JOIN events e ON tt.event_id = e.id
            WHERE t.user_id = '$user_id'
            ORDER BY t.tgl_transaksi DESC
            LIMIT 5
        ";
        $latest_transaksi = mysqli_query($conn, $sql_latest);
        ?>
        <div class="card border-0 shadow-sm mb-5">
            <div class="card-body">
                <?php if (mysqli_num_rows($latest_transaksi) == 0): ?>
                    <p class="text-center text-muted">Anda belum memiliki riwayat transaksi.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light"><tr><th>Event</th><th>Tiket</th><th>Tanggal Beli</th><th>Status</th><th>Aksi</th></tr></thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_assoc($latest_transaksi)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['title']) ?></td>
                                    <td><?= htmlspecialchars($row['nama_tiket']) ?></td>
                                    <td><?= date('d M Y', strtotime($row['tgl_transaksi'])) ?></td>
                                    <td>
                                        <?php 
                                        $status_class = ['PAID' => 'success', 'PENDING' => 'warning', 'REJECTED' => 'danger', 'EXPIRED' => 'secondary'];
                                        echo '<span class="badge bg-' . ($status_class[$row['status']] ?? 'secondary') . '">' . ucfirst($row['status']) . '</span>';
                                        ?>
                                    </td>
                                    <td>
                                        <a href="my_tickets.php" class="btn btn-sm btn-outline-primary">Detail</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <h3 class="mt-5 mb-3 text-primary fw-bold"><i class="bi bi-calendar-check me-2"></i> Event Tersedia untuk Dibeli</h3>
        
        <div class="card border-0 shadow-sm mb-4 p-3">
            <form method="GET" class="row g-3 align-items-center">
                <div class="col-md-5">
                    <label for="search_event_input" class="form-label visually-hidden">Cari Event</label>
                    <input type="text" class="form-control" id="search_event_input" name="search_event" placeholder="Cari Event (Judul)..." value="<?= htmlspecialchars($search_event) ?>">
                </div>
                <div class="col-md-4">
                    <label for="event_type_filter" class="form-label visually-hidden">Filter Jenis Event</label>
                    <select class="form-select" id="event_type_filter" name="event_type">
                        <option value="all" <?= $event_type_filter == 'all' ? 'selected' : '' ?>>Semua Jenis Event</option>
                        <?php foreach ($event_types as $type): ?>
                            <option value="<?= htmlspecialchars($type) ?>" <?= $event_type_filter == $type ? 'selected' : '' ?>>
                                <?= htmlspecialchars(ucfirst($type)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search me-1"></i> Cari Event</button>
                    <a href="dashboard.php" class="btn btn-outline-secondary" title="Reset Filter Event"><i class="bi bi-arrow-clockwise"></i></a>
                </div>
            </form>
        </div>

        <div class="row g-4 mb-5">
            <?php if (mysqli_num_rows($result_available_events) > 0): ?>
                <?php while($event = mysqli_fetch_assoc($result_available_events)): ?>
                    <div class="col-md-4 col-lg-3">
                        <div class="card event-card shadow-sm">
                            <img src="<?= $base_url ?>uploads/<?= htmlspecialchars($event['image'] ?? 'default.jpg') ?>" class="card-img-top event-card-img" alt="<?= htmlspecialchars($event['title']) ?>">
                            <div class="card-body">
                                <h6 class="card-title fw-bold text-truncate" title="<?= htmlspecialchars($event['title']) ?>"><?= htmlspecialchars($event['title']) ?></h6>
                                <p class="card-text mb-1"><i class="bi bi-calendar me-1 text-primary"></i> <?= date('d F Y', strtotime($event['event_date'])) ?></p>
                                <p class="card-text mb-2"><i class="bi bi-geo-alt me-1 text-danger"></i> <?= htmlspecialchars($event['location']) ?></p>
                                
                                <span class="badge bg-secondary mb-3"><?= htmlspecialchars(ucfirst($event['event_type'])) ?></span>
                                
                                <p class="fw-bold text-success mb-2">
                                    <?php 
                                        // Asumsi harga 0.00 berarti Gratis
                                        echo ($event['price'] == 0.00) ? 'Gratis' : 'Rp ' . number_format($event['price'], 0, ',', '.'); 
                                    ?>
                                </p>
                                
                                <a href="../event_detail.php?id=<?= $event['id'] ?>" class="btn btn-sm btn-primary w-100">Beli Tiket <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center" role="alert">
                        Tidak ada event yang tersedia saat ini, atau tidak ada yang cocok dengan pencarian Anda.
                    </div>
                </div>
            <?php endif; ?>
        </div>
        </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>