<?php
// peserta/change_password.php

require '../config.php';
checkRole(['user', 'panitia']);

if ($_SESSION['role'] != 'user') {
    header("Location: ../panitia/dashboard.php");
    exit;
}

$page_title = 'profile'; // Tetap aktifkan menu profile
$user_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

// --- LOGIKA UBAH KATA SANDI ---
if (isset($_POST['change_password'])) {
    $current_password = clean($_POST['current_password']);
    $new_password = clean($_POST['new_password']);
    $confirm_password = clean($_POST['confirm_password']);

    // 1. Ambil hash password lama dari database
    $sql_check = "SELECT password FROM users WHERE id = '$user_id'";
    $result_check = mysqli_query($conn, $sql_check);
    $user = mysqli_fetch_assoc($result_check);
    $hashed_password = $user['password'] ?? '';

    // 2. Verifikasi password lama
    if (!password_verify($current_password, $hashed_password)) {
        $message = "Kata sandi lama salah.";
        $message_type = 'danger';
    } 
    // 3. Verifikasi konfirmasi password baru
    elseif ($new_password !== $confirm_password) {
        $message = "Konfirmasi kata sandi baru tidak cocok.";
        $message_type = 'danger';
    } 
    // 4. Verifikasi panjang password baru (min 6 karakter)
    elseif (strlen($new_password) < 6) {
        $message = "Kata sandi baru minimal 6 karakter.";
        $message_type = 'danger';
    }
    else {
        // 5. Hash dan Update password baru
        $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $sql_update = "UPDATE users SET password = '$new_hashed_password' WHERE id = '$user_id'";
        
        if (mysqli_query($conn, $sql_update)) {
            $message = "Kata sandi berhasil diubah!";
            $message_type = 'success';
        } else {
            $message = "Gagal mengubah kata sandi: " . mysqli_error($conn);
            $message_type = 'danger';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ubah Kata Sandi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #dc3545, #ff4155);">
            <h3><i class="bi bi-key-fill me-2"></i> Ubah Kata Sandi</h3>
            <p class="mb-0">Pastikan Anda menggunakan kata sandi yang kuat dan unik.</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
                <?= $message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white fw-bold">Formulir Ubah Kata Sandi</div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Kata Sandi Lama</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            <hr>
                            <div class="mb-3">
                                <label for="new_password" class="form-label">Kata Sandi Baru</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                                <small class="form-text text-muted">Minimal 6 karakter.</small>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Konfirmasi Kata Sandi Baru</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="6">
                            </div>
                            <button type="submit" name="change_password" class="btn btn-danger"><i class="bi bi-check-circle me-1"></i> Perbarui Kata Sandi</button>
                            <a href="profile.php" class="btn btn-outline-secondary">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>