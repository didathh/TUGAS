<?php
// peserta/sidebar.php - Pastikan file ini berada di folder 'peserta/'

// $page_title harus didefinisikan di setiap file yang menggunakan sidebar
// Contoh: $page_title = 'dashboard';

$menu_items = [
    'dashboard' => ['icon' => 'bi-speedometer2', 'label' => 'Dashboard', 'url' => 'dashboard.php'],
    'my_tickets' => ['icon' => 'bi-ticket-fill', 'label' => 'Tiket Saya', 'url' => 'my_tickets.php'],
    'profile' => ['icon' => 'bi-person-circle', 'label' => 'Profil & Akun', 'url' => 'profile.php'],
];
?>
<div class="sidebar">
    <h4 class="text-center mt-3 mb-5 fw-bold text-white">SIMES PESERTA</h4>
    <nav class="nav flex-column">
        <?php foreach ($menu_items as $key => $item): ?>
            <a href="<?= $item['url'] ?>" class="nav-link <?= (isset($page_title) && $key == $page_title) ? 'active' : '' ?>">
                <i class="<?= $item['icon'] ?> me-2"></i> <?= $item['label'] ?>
            </a>
        <?php endforeach; ?>
        <hr class="text-white">
        <a href="../logout.php" class="nav-link"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
    </nav>
</div>