<?php
// peserta/payment.php

require '../config.php';
checkRole(['user', 'panitia']); 

if ($_SESSION['role'] != 'user' || !isset($_GET['trx_id'])) { 
    header("Location: my_tickets.php"); exit; 
}

$page_title = 'my_tickets';
$kode_transaksi = clean($_GET['trx_id']);
$user_id = $_SESSION['user_id'];
$msg = '';

// Ambil data transaksi
$sql_trx = "
    SELECT 
        t.*, e.title, tt.nama_tiket
    FROM transaksi t
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    WHERE kode_transaksi = '$kode_transaksi' AND t.user_id = '$user_id'
";
$trx = mysqli_fetch_assoc(mysqli_query($conn, $sql_trx));

// Jika transaksi tidak ditemukan
if (!$trx) {
    header("Location: my_tickets.php");
    exit;
}

// JIKA SUDAH DIVERIFIKASI (PAID) → LANGSUNG KE LIST TIKET
if ($trx['status'] == 'PAID') {
    header("Location: my_tickets.php?paid=success");
    exit;
}

// JIKA PENDING & SUDAH UPLOAD BUKTI
if ($trx['status'] == 'PENDING' && !empty($trx['bukti_transfer'])) {
    $msg = "<div class='alert alert-info'>
        Bukti transfer telah diunggah. Menunggu verifikasi dari panitia.
    </div>";
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && $trx['status'] == 'PENDING' && empty($trx['bukti_transfer'])) {
    $target_dir = "../uploads/bukti_transfer/";
    
    if (isset($_FILES['bukti']) && $_FILES['bukti']['error'] == 0) {
        $file_info = pathinfo($_FILES["bukti"]["name"]);
        $file_ext = strtolower($file_info["extension"]);
        
        // Validasi ekstensi
        $allowed_ext = ['jpg', 'jpeg', 'png'];
        if (!in_array($file_ext, $allowed_ext)) {
            $msg = "<div class='alert alert-danger'>Hanya file JPG, JPEG, dan PNG yang diizinkan.</div>";
        } else {
            $unique_name = $kode_transaksi . "_" . time() . "." . $file_ext;
            $target_file = $target_dir . $unique_name;
            
            // Pastikan folder uploads/bukti_transfer sudah ada dan writable
            if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
            
            if (move_uploaded_file($_FILES["bukti"]["tmp_name"], $target_file)) {
                $sql_update = "UPDATE transaksi SET bukti_transfer = '$unique_name' WHERE kode_transaksi = '$kode_transaksi'";
                if (mysqli_query($conn, $sql_update)) {
                    $msg = "<div class='alert alert-success'>Bukti transfer berhasil diunggah. Transaksi Anda akan diverifikasi oleh Admin dalam 1x24 jam.</div>";
                    // Redirect agar tidak double submit dan menampilkan status yang diperbarui
                    header("Location: my_tickets.php?msg=" . urlencode(strip_tags($msg))); exit;
                } else {
                    $msg = "<div class='alert alert-danger'>Gagal mengupdate database.</div>";
                }
            } else {
                $msg = "<div class='alert alert-danger'>Gagal mengunggah file. Pastikan ukuran file tidak melebihi batas upload server.</div>";
            }
        }
    } else {
        $msg = "<div class='alert alert-danger'>Pilih file bukti transfer.</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Konfirmasi Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <h2 class="mb-4 text-warning fw-bold">Konfirmasi Pembayaran</h2>
        
        <?= $msg ?>

        <?php if ($trx && $trx['status'] == 'PENDING' && empty($trx['bukti_transfer'])): ?>
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-warning text-dark">Detail Transaksi</div>
                <div class="card-body">
                    <p><strong>TRX ID:</strong> <?= htmlspecialchars($trx['kode_transaksi']) ?></p>
                    <p><strong>Event:</strong> <?= htmlspecialchars($trx['title']) ?> (<?= htmlspecialchars($trx['nama_tiket']) ?>)</p>
                    <p class="fs-4 fw-bold text-success">Total Bayar: <?= formatRupiah($trx['total_bayar']) ?></p>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-primary text-white">Upload Bukti Transfer</div>
                <div class="card-body">
                    <div class="alert alert-info">
                        Silakan transfer sebesar **<?= formatRupiah($trx['total_bayar']) ?>** ke rekening berikut:
                        <br><strong>Bank ABC | No. Rek: 1234567890 | Atas Nama: SIMES Payment Center</strong>
                    </div>

                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="bukti" class="form-label">Bukti Transfer (JPG/PNG)</label>
                            <input type="file" name="bukti" id="bukti" class="form-control" accept="image/jpeg,image/png" required>
                            <div class="form-text">Maksimal ukuran file 2MB.</div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg w-100">Konfirmasi Pembayaran</button>
                        <a href="my_tickets.php" class="btn btn-secondary mt-2 w-100">Batalkan / Kembali</a>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>