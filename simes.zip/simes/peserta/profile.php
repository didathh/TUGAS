<?php
// peserta/profile.php

require '../config.php';
// Pastikan fungsi checkRole dan clean didefinisikan di config.php
checkRole(['user', 'panitia']); 

if ($_SESSION['role'] != 'user') { 
    header("Location: ../panitia/dashboard.php"); 
    exit; 
}

$page_title = 'profile';
$user_id = $_SESSION['user_id'];
$msg = '';

// Ambil data user TERBARU
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id, name, email, phone, role FROM users WHERE id = '$user_id'"));

// Cek status request panitia terakhir
$request_status_query = "SELECT status FROM panitia_requests WHERE user_id = '$user_id' ORDER BY id DESC LIMIT 1";
$request_status_result = mysqli_query($conn, $request_status_query);
$request_status = mysqli_fetch_assoc($request_status_result);
$current_request_status = $request_status ? $request_status['status'] : null;

// Logika Update Profil
if (isset($_POST['update_profile'])) {
    $name = clean($_POST['name']);
    $email = clean($_POST['email']);
    $phone = clean($_POST['phone']);

    // Cek duplikasi email (kecuali email sendiri)
    $check_email = mysqli_query($conn, "SELECT id FROM users WHERE email = '$email' AND id != '$user_id'");
    if (mysqli_num_rows($check_email) > 0) {
        $msg = "<div class='alert alert-danger'>Email sudah digunakan oleh akun lain.</div>";
    } else {
        $sql_update = "UPDATE users SET name = '$name', email = '$email', phone = '$phone' WHERE id = '$user_id'";
        if (mysqli_query($conn, $sql_update)) {
            // Update session dan array $user
            $_SESSION['name'] = $name; 
            $user['name'] = $name; 
            $user['email'] = $email; 
            $user['phone'] = $phone; 
            $msg = "<div class='alert alert-success'>Profil berhasil diperbarui.</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Gagal memperbarui profil.</div>";
        }
    }
}

// Logika Request Panitia
if (isset($_POST['request_panitia'])) {
    if ($current_request_status != 'pending') { // Hanya izinkan request jika tidak sedang pending
        $reason = clean($_POST['reason']);
        // Pastikan tabel panitia_requests sudah ada dan memiliki kolom user_id, reason, dan status
        $sql_request = "INSERT INTO panitia_requests (user_id, reason, status) VALUES ('$user_id', '$reason', 'pending')";
        if (mysqli_query($conn, $sql_request)) {
            $current_request_status = 'pending';
            $msg = "<div class='alert alert-info'>Permintaan menjadi Panitia berhasil dikirim. Menunggu verifikasi Admin.</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Gagal mengirim permintaan.</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Profil & Akun</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #0d6efd, #0dcaf0);">
            <h3><i class="bi bi-person-fill me-2"></i> Kelola Profil Anda</h3>
            <p class="mb-0">Perbarui data pribadi dan ajukan permintaan peran panitia.</p>
        </div>
        
        <?= $msg ?>

        <div class="row g-4">
            
            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white"><i class="bi bi-info-circle me-1"></i> Informasi Dasar</div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label for="name" class="form-label">Nama Lengkap</label>
                                <input type="text" name="name" id="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email" id="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Nomor Telepon</label>
                                <input type="text" name="phone" id="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>">
                            </div>
                            <button type="submit" name="update_profile" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            <a href="change_password.php" class="btn btn-outline-secondary ms-2"><i class="bi bi-key me-1"></i> Ubah Password</a> 
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-info text-white"><i class="bi bi-person-badge-fill me-1"></i> Ajukan Jadi Panitia</div>
                    <div class="card-body d-flex flex-column justify-content-between">
                        <?php if ($user['role'] == 'panitia'): ?>
                            <div class="alert alert-success text-center">
                                <i class="bi bi-check-circle"></i> **Status Anda saat ini adalah Panitia.**
                            </div>
                            <p class="text-center">Anda dapat mengakses dashboard panitia untuk membuat event.</p>
                            <a href="../panitia/dashboard.php" class="btn btn-success w-100 mt-auto"><i class="bi bi-person-workspace"></i> Ke Dashboard Panitia</a>

                        <?php elseif ($current_request_status == 'pending'): ?>
                            <div class="alert alert-info text-center">
                                <i class="bi bi-clock"></i> Permintaan Anda sedang dalam proses verifikasi oleh Admin.
                            </div>
                            <p class="text-center small text-muted">Anda akan diberitahu melalui email jika status disetujui.</p>
                            
                        <?php elseif ($current_request_status == 'rejected'): ?>
                            <div class="alert alert-danger text-center">
                                <i class="bi bi-x-circle"></i> Permintaan terakhir Anda ditolak. Silakan ajukan ulang dengan alasan yang lebih baik.
                            </div>
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="reason" class="form-label">Alasan Mengajukan Ulang</label>
                                    <textarea name="reason" id="reason" class="form-control" rows="3" required></textarea>
                                </div>
                                <button type="submit" name="request_panitia" class="btn btn-info w-100">Ajukan Ulang</button>
                            </form>
                            
                        <?php else: // Belum pernah request ?>
                            <p>Tingkatkan peran Anda menjadi Panitia untuk dapat membuat dan mengelola event sendiri di SIMES. Ajukan permohonan Anda di bawah ini.</p>
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="reason" class="form-label">Alasan Mengajukan</label>
                                    <textarea name="reason" id="reason" class="form-control" rows="3" required></textarea>
                                </div>
                                <button type="submit" name="request_panitia" class="btn btn-info w-100">Ajukan Jadi Panitia</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>