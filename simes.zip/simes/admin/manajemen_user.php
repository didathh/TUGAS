<?php
require '../config.php';
checkLogin();

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$current_page = basename(__FILE__);
$msg = "";
$type = "";

// =====================
// PESAN DARI REDIRECT
// =====================
if (isset($_GET['msg'])) {
    $msg  = clean($_GET['msg']);
    $type = clean($_GET['type']);
}

// =====================
// PROSES UBAH ROLE
// =====================
if (isset($_POST['change_role'])) {
    $uid      = clean($_POST['user_id']);
    $new_role = clean($_POST['new_role']);

    if ($uid == 1 && $new_role !== 'admin') {
        $msg  = "Admin Utama (ID 1) tidak bisa diubah rolenya selain Admin.";
        $type = "danger";
    } elseif (!in_array($new_role, ['user', 'panitia', 'admin'])) {
        $msg  = "Role yang dipilih tidak valid.";
        $type = "danger";
    } else {
        mysqli_query($conn, "UPDATE users SET role='$new_role' WHERE id='$uid'");
        $msg  = "Role pengguna berhasil diubah menjadi " . ucfirst($new_role) . ".";
        $type = "success";
    }
}

// =====================
// PROSES HAPUS USER
// =====================
if (isset($_GET['delete_id'])) {
    $uid = clean($_GET['delete_id']);

    if ($uid == 1) {
        $msg  = "Admin Utama (ID 1) tidak bisa dihapus.";
        $type = "danger";
    } else {
        mysqli_query($conn, "DELETE FROM panitia_requests WHERE user_id='$uid'");
        mysqli_query($conn, "DELETE FROM users WHERE id='$uid'");
        header("Location: manajemen_user.php?msg=Pengguna berhasil dihapus.&type=success");
        exit;
    }
}

// =====================
// DATA USER
// =====================
$users = mysqli_query($conn, "SELECT * FROM users ORDER BY role DESC, created_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>

    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES ADMIN</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
            <a href="manajemen_user.php" class="<?php echo ($current_page == 'manajemen_user.php') ? 'active' : ''; ?>"><i class="bi bi-people-fill me-2"></i> Manajemen User</a>
            <a href="manajemen_event.php" class="<?php echo ($current_page == 'manajemen_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-event me-2"></i> Kelola Event</a>
            <a href="verifikasi_panitia.php" class="<?php echo ($current_page == 'verifikasi_panitia.php') ? 'active' : ''; ?>"><i class="bi bi-person-check-fill me-2"></i> Verifikasi Panitia</a>
            <a href="verifikasi_event.php" class="<?php echo ($current_page == 'verifikasi_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-check me-2"></i> Verifikasi Event</a>
            <a href="laporan_keuangan.php" class="<?php echo ($current_page == 'laporan_keuangan.php') ? 'active' : ''; ?>"><i class="bi bi-bar-chart-line-fill me-2"></i> Laporan Keuangan</a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

<div class="main-content">
    <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm"
         style="background: linear-gradient(135deg,#1d3557,#457b9d);">
        <h3><i class="bi bi-people-fill me-2"></i> Manajemen Pengguna</h3>
        <p class="mb-0">Kelola akun user, panitia, dan admin.</p>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-<?= ($type=='success')?'success':'danger' ?> alert-dismissible fade show">
            <?= htmlspecialchars($msg) ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th><th>Nama</th><th>Email</th><th>Role</th><th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $no=1; while($row=mysqli_fetch_assoc($users)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td>
                                <?php
                                $badge = [
                                    'admin'=>'danger',
                                    'panitia'=>'primary',
                                    'user'=>'secondary',
                                    'peserta'=>'secondary'
                                ];
                                ?>
                                <span class="badge bg-<?= $badge[$row['role']] ?? 'secondary' ?>">
                                    <?= ucfirst($row['role']=='peserta'?'user':$row['role']) ?>
                                </span>
                            </td>
                            <td>
                                <!-- UBAH ROLE -->
                                <button class="btn btn-sm btn-primary me-2"
                                        data-bs-toggle="modal"
                                        data-bs-target="#roleModal<?= $row['id'] ?>">
                                    <i class="bi bi-pencil"></i>
                                </button>

                                <!-- HAPUS USER (TETAP ADA) -->
                                <a href="?delete_id=<?= $row['id'] ?>"
                                   class="btn btn-sm btn-danger <?= ($row['id']==1)?'disabled':'' ?>"
                                   onclick="return confirm('Yakin hapus user <?= htmlspecialchars($row['name']) ?>?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_data_seek($users, 0);
while($row=mysqli_fetch_assoc($users)):
?>
<div class="modal fade" id="roleModal<?= $row['id'] ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="user_id" value="<?= $row['id'] ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Ubah Role</h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php if ($row['id']==1): ?>
                        <p class="text-danger small">Admin Utama tidak dapat diubah.</p>
                    <?php endif; ?>
                    <select name="new_role" class="form-select" <?= ($row['id']==1)?'disabled':'' ?>>
                        <option value="user" <?= ($row['role']=='user'||$row['role']=='peserta')?'selected':'' ?>>User</option>
                        <option value="panitia" <?= ($row['role']=='panitia')?'selected':'' ?>>Panitia</option>
                        <option value="admin" <?= ($row['role']=='admin')?'selected':'' ?>>Admin</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <?php if ($row['id']!=1): ?>
                        <button type="submit" name="change_role" class="btn btn-primary">Simpan</button>
                    <?php else: ?>
                        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endwhile; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
