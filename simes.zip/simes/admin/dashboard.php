<?php
// admin/dashboard.php

require '../config.php';
checkLogin();

if ($_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

// --- LOGIKA STATISTIK ---
// 1. Total Pengguna
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as total FROM users"))['total'];
$pending_trans = 0; 
// 2. Permintaan Panitia Pending
$pending_panitia = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as total FROM panitia_requests WHERE status = 'PENDING'"))['total'];
// 3. Event Menunggu Verifikasi (Pending/Deletion)
$pending_events = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as total FROM events WHERE status IN ('pending', 'deletion_requested')"))['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES ADMIN</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
            <a href="manajemen_user.php" class="<?php echo ($current_page == 'manajemen_user.php') ? 'active' : ''; ?>"><i class="bi bi-people-fill me-2"></i> Manajemen User</a>
            <a href="manajemen_event.php" class="<?php echo ($current_page == 'manajemen_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-event me-2"></i> Kelola Event</a>
            <a href="verifikasi_panitia.php" class="<?php echo ($current_page == 'verifikasi_panitia.php') ? 'active' : ''; ?>"><i class="bi bi-person-check-fill me-2"></i> Verifikasi Panitia</a>
            <a href="verifikasi_event.php" class="<?php echo ($current_page == 'verifikasi_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-check me-2"></i> Verifikasi Event</a>
            <a href="laporan_keuangan.php" class="<?php echo ($current_page == 'laporan_keuangan.php') ? 'active' : ''; ?>"><i class="bi bi-bar-chart-line-fill me-2"></i> Laporan Keuangan</a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #1d3557, #457b9d);">
            <h3>Halo, Administrator!</h3>
            <p class="mb-0">Selamat datang di panel kontrol utama SIMES. Ada beberapa hal yang perlu perhatian Anda hari ini.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted">Total Pengguna</h6>
                            <h2 class="fw-bold text-primary"><?= $total_users ?></h2>
                        </div>
                        <div class="fs-1 text-primary opacity-25"><i class="bi bi-people"></i></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted">Request Panitia</h6>
                            <h2 class="fw-bold text-info"><?= $pending_panitia ?></h2>
                        </div>
                        <div class="fs-1 text-info opacity-25"><i class="bi bi-person-badge"></i></div>
                    </div>
                    <a href="verifikasi_panitia.php" class="small text-decoration-none mt-2 d-block">Lihat Detail &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted">Verifikasi Event</h6>
                            <h2 class="fw-bold text-danger"><?= $pending_events ?></h2>
                        </div>
                        <div class="fs-1 text-danger opacity-25"><i class="bi bi-calendar-event"></i></div>
                    </div>
                    <a href="verifikasi_event.php" class="small text-decoration-none mt-2 d-block">Lihat Detail &rarr;</a>
                </div>
            </div>
        </div>
        
        </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>