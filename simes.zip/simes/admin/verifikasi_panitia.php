<?php
// admin/verifikasi_panitia.php

require '../config.php';
// Memastikan user sudah login
checkLogin();

// Pastikan hanya admin yang bisa mengakses halaman ini
if ($_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

$current_page = basename(__FILE__); // Digunakan untuk penanda active di sidebar

// Logika POST: Menyetujui atau Menolak
if (isset($_POST['action'])) {
    $req_id = clean($_POST['req_id']);
    $uid = clean($_POST['user_id']);
    $act = $_POST['action'];

    if ($act == 'approve') {
        // Update role user jadi panitia
        mysqli_query($conn, "UPDATE users SET role = 'panitia' WHERE id = '$uid'");
        // Update status request
        mysqli_query($conn, "UPDATE panitia_requests SET status = 'approved' WHERE id = '$req_id'"); 
        $msg = "User berhasil dijadikan Panitia.";
    } else {
        mysqli_query($conn, "UPDATE panitia_requests SET status = 'rejected' WHERE id = '$req_id'");
        $msg = "Pengajuan ditolak.";
    }
    header("Location: verifikasi_panitia.php?msg=" . urlencode($msg)); 
    exit;
}

// Query mengambil data request
// Menggunakan pr.* untuk mengambil SEMUA kolom, termasuk 'reason'
$requests = mysqli_query($conn, "SELECT pr.*, u.name, u.email FROM panitia_requests pr JOIN users u ON pr.user_id = u.id WHERE pr.status = 'pending'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Verifikasi Panitia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
<div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES ADMIN</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
            <a href="manajemen_user.php" class="<?php echo ($current_page == 'manajemen_user.php') ? 'active' : ''; ?>"><i class="bi bi-people-fill me-2"></i> Manajemen User</a>
            <a href="manajemen_event.php" class="<?php echo ($current_page == 'manajemen_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-event me-2"></i> Kelola Event</a>
            <a href="verifikasi_panitia.php" class="<?php echo ($current_page == 'verifikasi_panitia.php') ? 'active' : ''; ?>"><i class="bi bi-person-check-fill me-2"></i> Verifikasi Panitia</a>
            <a href="verifikasi_event.php" class="<?php echo ($current_page == 'verifikasi_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-check me-2"></i> Verifikasi Event</a>
            <a href="laporan_keuangan.php" class="<?php echo ($current_page == 'laporan_keuangan.php') ? 'active' : ''; ?>"><i class="bi bi-bar-chart-line-fill me-2"></i> Laporan Keuangan</a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #1d3557, #457b9d);">
            <h3><i class="bi bi-person-check-fill me-2"></i> Verifikasi Pengajuan Panitia</h3>
            <p class="mb-0">Tinjau dan proses permintaan pengguna yang ingin menjadi panitia event.</p>
        </div>
        <?php if(isset($_GET['msg'])): ?><div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div><?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <?php if(mysqli_num_rows($requests) == 0): ?>
                    <p class="text-muted text-center">Tidak ada pengajuan baru.</p>
                <?php else: ?>
                    <table class="table align-middle">
                        <thead><tr><th>User</th><th>Alasan</th><th>Aksi</th></tr></thead>
                        <tbody>
                            <?php while($row=mysqli_fetch_assoc($requests)): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($row['name'] ?? 'Tanpa Nama') ?></strong><br>
                                    <small class="text-muted"><?= htmlspecialchars($row['email'] ?? '-') ?></small>
                                </td>
                                
                                <td><?= htmlspecialchars($row['reason'] ?? '-') ?></td>
                                
                                <td>
                                    <form method="POST" class="d-flex gap-2">
                                        <input type="hidden" name="req_id" value="<?= $row['id'] ?>">
                                        <input type="hidden" name="user_id" value="<?= $row['user_id'] ?>">
                                        <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">Terima</button>
                                        <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">Tolak</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>