<?php
require '../config.php';
checkLogin();

// --- LOGIKA PENGAMBILAN DATA KEUANGAN ---

// 1. Total Pendapatan (Omset)
$query_total = mysqli_query($conn, "SELECT SUM(total_bayar) as omset FROM transaksi WHERE status='PAID'");
$data_total = mysqli_fetch_assoc($query_total);
// Menggunakan ?? 0 untuk mencegah error number_format jika nilai NULL
$total_omset = $data_total['omset'] ?? 0;

// 2. Total Transaksi Lunas
$paid_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as total FROM transaksi WHERE status='PAID'"))['total'] ?? 0;

// 3. Total Transaksi Pending (Menunggu Bukti/Verifikasi)
$pending_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as total FROM transaksi WHERE status='PENDING' AND bukti_transfer IS NOT NULL"))['total'] ?? 0;

// 4. Total Transaksi Gagal (Rejected/Expired)
$failed_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) as total FROM transaksi WHERE status IN ('REJECTED', 'EXPIRED')"))['total'] ?? 0;


// List Transaksi Paid untuk tabel detail
$trans = mysqli_query($conn, "SELECT t.*, u.name, e.title FROM transaksi t JOIN users u ON t.user_id=u.id JOIN tipe_tiket tt ON t.tipe_tiket_id=tt.id JOIN events e ON tt.event_id=e.id WHERE t.status='PAID' ORDER BY t.tgl_transaksi DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Keuangan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
<div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES ADMIN</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
            <a href="manajemen_user.php" class="<?php echo ($current_page == 'manajemen_user.php') ? 'active' : ''; ?>"><i class="bi bi-people-fill me-2"></i> Manajemen User</a>
            <a href="manajemen_event.php" class="<?php echo ($current_page == 'manajemen_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-event me-2"></i> Kelola Event</a>
            <a href="verifikasi_panitia.php" class="<?php echo ($current_page == 'verifikasi_panitia.php') ? 'active' : ''; ?>"><i class="bi bi-person-check-fill me-2"></i> Verifikasi Panitia</a>
            <a href="verifikasi_event.php" class="<?php echo ($current_page == 'verifikasi_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-check me-2"></i> Verifikasi Event</a>
            <a href="laporan_keuangan.php" class="<?php echo ($current_page == 'laporan_keuangan.php') ? 'active' : ''; ?>"><i class="bi bi-bar-chart-line-fill me-2"></i> Laporan Keuangan</a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <h2 class="mb-4 text-primary fw-bold">Laporan Keuangan</h2>

        <div class="row g-4 mb-5">
            
            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #198754!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-success fw-bold">Total Omset</h6>
                            <h2 class="fw-bold">Rp <?= number_format($total_omset, 0, ',', '.') ?></h2>
                        </div>
                        <div class="fs-1 text-success opacity-25"><i class="bi bi-cash-stack"></i></div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #0dcaf0!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-info fw-bold">Transaksi Lunas</h6>
                            <h2 class="fw-bold"><?= $paid_count ?></h2>
                        </div>
                        <div class="fs-1 text-info opacity-25"><i class="bi bi-check-circle"></i></div>
                    </div>
                </div>
            </div>
           
            <div class="col-md-4">
                <div class="card p-3 border-0 shadow-sm h-100" style="border-left: 5px solid #dc3545!important;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-danger fw-bold">Transaksi Gagal</h6>
                            <h2 class="fw-bold"><?= $failed_count ?></h2>
                        </div>
                        <div class="fs-1 text-danger opacity-25"><i class="bi bi-x-octagon"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">Riwayat Transaksi Sukses</h5>
            </div>
            <div class="card-body">
                <?php if(mysqli_num_rows($trans) == 0): ?>
                    <p class="text-center text-muted p-3">Belum ada transaksi yang lunas.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped align-middle">
                            <thead><tr><th>Tanggal</th><th>TRX ID</th><th>User</th><th>Event</th><th>Nominal</th></tr></thead>
                            <tbody>
                                <?php while($row=mysqli_fetch_assoc($trans)): ?>
                                <tr>
                                    <td><?= date('d/m/Y H:i', strtotime($row['tgl_transaksi'])) ?></td>
                                    <td><?= htmlspecialchars($row['kode_transaksi']) ?></td>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars($row['title']) ?></td>
                                    <td class="fw-bold text-success">Rp <?= number_format($row['total_bayar']) ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>