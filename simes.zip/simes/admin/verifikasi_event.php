<?php
// admin/verifikasi_event.php

require '../config.php';
checkLogin();

if ($_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit;
}

$current_page = basename(__FILE__);

// --- LOGIKA VERIFIKASI (TERIMA/TOLAK) ---
if (isset($_POST['action'])) {
    $event_id = clean($_POST['event_id']);
    $action = clean($_POST['action']);

    if ($action == 'approve') {
        // Update status event menjadi 'published'
        mysqli_query($conn, "UPDATE events SET status = 'published' WHERE id = '$event_id'");
        $_SESSION['message'] = "success: Event ID $event_id telah *DITERIMA* dan dipublikasikan.";
    } elseif ($action == 'reject') {
        // Update status event menjadi 'rejected'
        mysqli_query($conn, "UPDATE events SET status = 'rejected' WHERE id = '$event_id'");
        $_SESSION['message'] = "warning: Event ID $event_id telah *DITOLAK*.";
    }
    header("Location: verifikasi_event.php");
    exit;
}


// --- PENGAMBILAN DATA EVENT PENDING ---
$sql_events = "
    SELECT 
        e.*, 
        u.name AS organizer_name
    FROM events e
    JOIN users u ON e.organizer_id = u.id
    WHERE e.status = 'pending'
    ORDER BY e.event_date ASC
";
$result_events = mysqli_query($conn, $sql_events);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Verifikasi Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>
<div class="sidebar">
        <h4 class="text-center mt-3 mb-5 fw-bold">SIMES ADMIN</h4>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
            <a href="manajemen_user.php" class="<?php echo ($current_page == 'manajemen_user.php') ? 'active' : ''; ?>"><i class="bi bi-people-fill me-2"></i> Manajemen User</a>
            <a href="manajemen_event.php" class="<?php echo ($current_page == 'manajemen_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-event me-2"></i> Kelola Event</a>
            <a href="verifikasi_panitia.php" class="<?php echo ($current_page == 'verifikasi_panitia.php') ? 'active' : ''; ?>"><i class="bi bi-person-check-fill me-2"></i> Verifikasi Panitia</a>
            <a href="verifikasi_event.php" class="<?php echo ($current_page == 'verifikasi_event.php') ? 'active' : ''; ?>"><i class="bi bi-calendar-check me-2"></i> Verifikasi Event</a>
            <a href="laporan_keuangan.php" class="<?php echo ($current_page == 'laporan_keuangan.php') ? 'active' : ''; ?>"><i class="bi bi-bar-chart-line-fill me-2"></i> Laporan Keuangan</a>
            <hr class="text-white">
            <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm" style="background: linear-gradient(135deg, #1d3557, #457b9d);">
            <h3><i class="bi bi-calendar-check me-2"></i> Verifikasi Event</h3>
            <p class="mb-0">Tinjau dan setujui event yang diajukan oleh Panitia sebelum dipublikasikan.</p>
        </div>
        
        <?php 
        if (isset($_SESSION['message'])) {
            list($type, $msg_text) = explode(': ', $_SESSION['message'], 2);
            $alert_class = ($type == 'success') ? 'alert-success' : 'alert-warning';
            echo "<div class='alert $alert_class alert-dismissible fade show' role='alert'>
                    " . htmlspecialchars($msg_text) . "
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>";
            unset($_SESSION['message']);
        }
        ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped align-middle">
                        <thead class="table-light">
                            <tr><th>Event</th><th>Tanggal</th><th>Penyelenggara</th><th>Harga Tiket</th><th>Aksi</th></tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result_events) > 0): ?>
                                <?php
                                $modals = '';
                                while($event = mysqli_fetch_assoc($result_events)):
                                ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($event['title']) ?></strong><br>
                                        <small class="text-muted"><?= htmlspecialchars($event['location']) ?></small>
                                    </td>
                                    <td><?= date('d M Y', strtotime($event['event_date'])) ?></td>
                                    <td><?= htmlspecialchars($event['organizer_name']) ?></td>
                                    <td><?= 'Rp ' . number_format($event['price'] ?? 0, 0, ',', '.') ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info text-white" data-bs-toggle="modal" data-bs-target="#detailModal<?= $event['id'] ?>">Detail</button>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="event_id" value="<?= $event['id'] ?>">
                                            <button type="submit" name="action" value="approve" class="btn btn-sm btn-success">Setujui</button>
                                        </form>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="event_id" value="<?= $event['id'] ?>">
                                            <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger">Tolak</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                                // Build modal HTML separately to avoid placing <div> inside <tbody> (invalid HTML)
                                $modal = <<<HTML
<div class="modal fade" id="detailModal{$event['id']}" tabindex="-1" aria-labelledby="detailModalLabel{$event['id']}" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel{$event['id']}">Detail Event: {title}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><strong>Penyelenggara:</strong> {organizer}</p>
                <p><strong>Tanggal Event:</strong> {date}</p>
                <p><strong>Lokasi:</strong> {location}</p>
                <p><strong>Kapasitas:</strong> {capacity} peserta</p>
                <p><strong>Harga Tiket:</strong> {price}</p>
                <p><strong>Deskripsi:</strong></p>
                <div class="alert alert-secondary">{description}</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
HTML;

                                // Replace placeholders for this modal only
                                $modal = str_replace('{organizer}', htmlspecialchars($event['organizer_name']), $modal);
                                $modal = str_replace('{date}', date('d M Y', strtotime($event['event_date'])), $modal);
                                $modal = str_replace('{location}', htmlspecialchars($event['location']), $modal);
                                $modal = str_replace('{capacity}', number_format($event['capacity'] ?? 0), $modal);
                                $modal = str_replace('{price}', 'Rp ' . number_format($event['price'] ?? 0, 0, ',', '.'), $modal);
                                $modal = str_replace('{description}', nl2br(htmlspecialchars($event['description'])), $modal);
                                $modal = str_replace('{title}', htmlspecialchars($event['title']), $modal);

                                $modals .= $modal;
                                endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center text-muted">Tidak ada event yang perlu diverifikasi saat ini.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (!empty($modals)) { echo $modals; } ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>