<?php
// admin/manajemen_event.php

require '../config.php';
checkLogin();

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$current_page = basename(__FILE__);

// Handle action
if (isset($_POST['action'])) {
    $event_id = clean($_POST['event_id']);
    $action   = clean($_POST['action']);

    if ($action === 'publish') {
        mysqli_query($conn, "UPDATE events SET status='published' WHERE id='$event_id'");
        $_SESSION['message'] = "success: Event ID $event_id berhasil dipublikasikan.";
    } elseif ($action === 'reject') {
        mysqli_query($conn, "UPDATE events SET status='rejected' WHERE id='$event_id'");
        $_SESSION['message'] = "warning: Event ID $event_id berhasil ditolak.";
    } elseif ($action === 'delete') {
        mysqli_query($conn, "DELETE FROM events WHERE id='$event_id'");
        $_SESSION['message'] = "danger: Event ID $event_id telah dihapus permanen.";
    }

    header("Location: manajemen_event.php");
    exit;
}

// Ambil data event
$sql_events = "
    SELECT e.*, u.name AS organizer_name
    FROM events e
    JOIN users u ON e.organizer_id = u.id
    ORDER BY e.id DESC
";
$result_events = mysqli_query($conn, $sql_events);

// INISIALISASI MODALS
$modals = '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manajemen Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body>

<div class="sidebar">
    <h4 class="text-center mt-3 mb-5 fw-bold">SIMES ADMIN</h4>
    <nav class="nav flex-column">
        <a href="dashboard.php" class="<?= ($current_page=='dashboard.php')?'active':'' ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
        <a href="manajemen_user.php" class="<?= ($current_page=='manajemen_user.php')?'active':'' ?>"><i class="bi bi-people-fill me-2"></i>Manajemen User</a>
        <a href="manajemen_event.php" class="<?= ($current_page=='manajemen_event.php')?'active':'' ?>"><i class="bi bi-calendar-event me-2"></i>Kelola Event</a>
        <a href="verifikasi_panitia.php" class="<?= ($current_page=='verifikasi_panitia.php')?'active':'' ?>"><i class="bi bi-person-check-fill me-2"></i>Verifikasi Panitia</a>
        <a href="verifikasi_event.php" class="<?= ($current_page=='verifikasi_event.php')?'active':'' ?>"><i class="bi bi-calendar-check me-2"></i>Verifikasi Event</a>
        <a href="laporan_keuangan.php" class="<?= ($current_page=='laporan_keuangan.php')?'active':'' ?>"><i class="bi bi-bar-chart-line-fill me-2"></i>Laporan Keuangan</a>
        <hr class="text-white">
        <a href="../logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="welcome-header text-white mb-4 p-4 rounded-3 shadow-sm"
         style="background: linear-gradient(135deg,#1d3557,#457b9d);">
        <h3><i class="bi bi-calendar-event me-2"></i>Manajemen Semua Event</h3>
        <p class="mb-0">Kelola, publikasikan, tolak, atau hapus semua event.</p>
    </div>

    <?php if (isset($_SESSION['message'])):
        list($type, $msg) = explode(': ', $_SESSION['message'], 2);
        $cls = ($type=='success')?'alert-success':(($type=='warning')?'alert-warning':'alert-danger');
    ?>
        <div class="alert <?= $cls ?> alert-dismissible fade show">
            <?= htmlspecialchars($msg) ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php unset($_SESSION['message']); endif; ?>

    <div class="card shadow-sm">
        <div class="card-body table-responsive">
            <table class="table table-striped align-middle">
                <thead class="table-light">
                <tr>
                    <th>Event</th>
                    <th>Penyelenggara</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>

                <?php if (mysqli_num_rows($result_events) > 0): ?>
                    <?php while ($event = mysqli_fetch_assoc($result_events)): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($event['title']) ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars($event['location']) ?></small>
                            </td>
                            <td><?= htmlspecialchars($event['organizer_name']) ?></td>
                            <td><?= date('d M Y', strtotime($event['event_date'])) ?></td>
                            <td>
                                <?php
                                $map = ['pending'=>'warning','published'=>'success','rejected'=>'danger'];
                                $b = $map[strtolower($event['status'])] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?= $b ?>"><?= ucfirst($event['status']) ?></span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-info text-white"
                                        data-bs-toggle="modal"
                                        data-bs-target="#detailModal<?= $event['id'] ?>">
                                    Detail
                                </button>

                                <?php if (strtolower($event['status']) !== 'published'): ?>
                                    <form method="post" class="d-inline">
                                        <input type="hidden" name="event_id" value="<?= $event['id'] ?>">
                                        <button name="action" value="publish" class="btn btn-sm btn-success">Publish</button>
                                    </form>
                                <?php endif; ?>

                                <?php if (strtolower($event['status']) !== 'rejected'): ?>
                                    <form method="post" class="d-inline">
                                        <input type="hidden" name="event_id" value="<?= $event['id'] ?>">
                                        <button name="action" value="reject" class="btn btn-sm btn-danger">Tolak</button>
                                    </form>
                                <?php endif; ?>

                                <form method="post" class="d-inline"
                                      onsubmit="return confirm('Hapus event ini?')">
                                    <input type="hidden" name="event_id" value="<?= $event['id'] ?>">
                                    <button name="action" value="delete"
                                            class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>

                        <?php
                        // MODAL DETAIL
                        $title = htmlspecialchars($event['title']);
                        $org   = htmlspecialchars($event['organizer_name']);
                        $loc   = htmlspecialchars($event['location']);
                        $desc  = nl2br(htmlspecialchars($event['description']));
                        $date  = date('d M Y', strtotime($event['event_date']));
                        $cap   = number_format($event['capacity'] ?? 0);
                        $price = number_format($event['price'] ?? 0, 0, ',', '.');

                        $modals .= <<<HTML
<div class="modal fade" id="detailModal{$event['id']}" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detail Event: {$title}</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p><strong>Penyelenggara:</strong> {$org}</p>
        <p><strong>Tanggal:</strong> {$date}</p>
        <p><strong>Lokasi:</strong> {$loc}</p>
        <p><strong>Kapasitas:</strong> {$cap} peserta</p>
        <p><strong>Harga:</strong> Rp {$price}</p>
        <div class="alert alert-secondary">{$desc}</div>
      </div>
    </div>
  </div>
</div>
HTML;
                        ?>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Tidak ada event.</td>
                    </tr>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- CETAK SEMUA MODAL -->
<?= $modals ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
