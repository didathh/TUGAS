<?php
// C:\laragon\www\simes\config.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost:3306';
$user = 'root';
$pass = '';
$db   = 'simes_db';

$base_url = "http://localhost/simes/";

// Koneksi Database
$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

/*
|--------------------------------------------------------------------------
| AUTH FUNCTIONS
|--------------------------------------------------------------------------
*/

function isLoggedIn() {
    return isset($_SESSION['user_id'], $_SESSION['role']);
}

function checkLogin() {
    if (!isLoggedIn()) {
        header("Location: " . $GLOBALS['base_url'] . "login.php");
        exit;
    }
}

function checkRole(array $allowed_roles) {
    checkLogin();

    // NORMALISASI ROLE (INI KUNCI PERBAIKAN)
    $role = strtolower(trim($_SESSION['role']));

    if (!in_array($role, $allowed_roles, true)) {
        header("Location: " . $GLOBALS['base_url'] . "index.php");
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function clean($data) {
    global $conn;
    return mysqli_real_escape_string($conn, htmlspecialchars(trim($data)));
}

function getEventTicketPrice($event_id) {
    global $conn;

    $sql = "SELECT MIN(harga) AS min_price FROM tipe_tiket WHERE event_id = '$event_id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if (!$row || $row['min_price'] === null) {
        $fallback = mysqli_query($conn, "SELECT price FROM events WHERE id = '$event_id'");
        $row_fb = mysqli_fetch_assoc($fallback);
        return $row_fb ? $row_fb['price'] : 0;
    }

    return $row['min_price'];
}

function formatRupiah($number) {
    $num = is_numeric($number) ? $number : 0;
    return 'Rp ' . number_format($num, 0, ',', '.');
}

define('WA_PANITIA', '6282241105099');
define('SIMES_NAME', 'SIMES Event Ticketing System');
