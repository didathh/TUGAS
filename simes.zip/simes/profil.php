<?php
require 'config.php';
checkLogin();
$user_id = $_SESSION['user_id'];

// Ambil data user
$user_data = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$user = mysqli_fetch_assoc($user_data);

// Cek status pengajuan panitia saat ini (hanya jika rolenya masih peserta)
$panitia_status = null;
if ($user['role'] == 'user') {
    $q_status = mysqli_query($conn, "SELECT status, reason FROM panitia_requests WHERE user_id = '$user_id' ORDER BY id DESC LIMIT 1");
    if (mysqli_num_rows($q_status) > 0) {
        $panitia_status = mysqli_fetch_assoc($q_status);
    }
}

// Logika Pengajuan Panitia
if (isset($_POST['ajukan_panitia'])) {
    $reason = clean($_POST['reason']);
    
    // Pastikan tidak ada pengajuan pending aktif
    if ($panitia_status && $panitia_status['status'] == 'pending') {
        $error = "Pengajuan Anda masih dalam proses verifikasi.";
    } else {
        // Insert pengajuan baru
        $sql_ajukan = "INSERT INTO panitia_requests (user_id, reason, status) VALUES ('$user_id', '$reason', 'pending')";
        if (mysqli_query($conn, $sql_ajukan)) {
            $success = "Pengajuan Panitia berhasil dikirim. Silakan tunggu verifikasi Admin.";
            // Refresh status
            header("Location: profil.php?msg=success_submit");
            exit;
        } else {
            $error = "Gagal mengirim pengajuan.";
        }
    }
}
?>
<?php
// Tentukan tujuan redirect berdasarkan role
$back_link = ($_SESSION['role'] == 'user') ? $base_url . "index.php" : $base_url . $_SESSION['role'] . "/dashboard.php";
$button_text = ($_SESSION['role'] == 'user') ? 'Ke Marketplace' : 'Ke Dashboard';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Profil Pengguna</h2>
    <a href="<?= $back_link ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Kembali <?= $button_text ?>
    </a>
</div>
<!DOCTYPE html>
<html>
<head>
    <title>Profil Pengguna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= $base_url ?>style.css" rel="stylesheet"> 
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Profil Pengguna</h4>
            </div>
            <div class="card-body">
                <p><strong>Nama:</strong> <?= $user['name'] ?></p>
                <p><strong>Email:</strong> <?= $user['email'] ?></p>
                <p><strong>Role Saat Ini:</strong> <span class="badge bg-secondary"><?= ucfirst($user['role']) ?></span></p>
                
                <hr>

                <?php if ($user['role'] == 'user'): ?>
                    <h5>Ajukan Diri Sebagai Panitia</h5>
                    <?php if ($panitia_status): ?>
                        <div class="alert alert-info">
                            Status Pengajuan Terakhir: 
                            <span class="fw-bold text-uppercase"><?= $panitia_status['status'] ?></span>
                            <br>Alasan: 
                            <span class="fst-italic small"><?= $panitia_status['reason'] ?></span>
                            <?php if ($panitia_status['status'] == 'rejected'): ?>
                                <br>Anda dapat mengajukan ulang.
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!$panitia_status || $panitia_status['status'] != 'pending'): ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label for="reason">Mengapa Anda ingin menjadi Panitia?</label>
                            <textarea name="reason" class="form-control" rows="3" required></textarea>
                        </div>
                        <button type="submit" name="ajukan_panitia" class="btn btn-warning">Ajukan Sekarang</button>
                    </form>
                    <?php endif; ?>

                <?php elseif ($user['role'] == 'panitia'): ?>
                     <div class="alert alert-success">Anda telah disetujui sebagai Panitia. Silakan akses <a href="panitia/dashboard.php">Dashboard Panitia</a> Anda.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>