<?php
require 'config.php';
checkLogin();
$id = $_SESSION['user_id'];
$query = mysqli_query($conn, "SELECT t.*, e.title, e.event_date 
                              FROM transaksi t 
                              JOIN events e ON t.event_id = e.id 
                              WHERE t.user_id = '$id' 
                              ORDER BY t.id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tiket Saya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?= $base_url ?>style.css" rel="stylesheet"> 
</head>
<body class="bg-light">
    <div class="container mt-5">
        <h3>Riwayat Tiket Saya</h3>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Riwayat Tiket Saya</h2>
            <a href="index.php" class="btn btn-primary">
                <i class="bi bi-house-door"></i> Ke Beranda
            </a>
        </div>
        <?php while($row = mysqli_fetch_assoc($query)): ?>
            <div class="card mb-3 shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5><?= $row['title'] ?></h5>
                        <p class="mb-1">Tanggal: **<?= $row['event_date'] ?>**</p>
                        <p class="mb-1 small">Kode Transaksi: **<?= $row['transaction_code'] ?>**</p>
                        
                        <?php 
                        $status_class = match ($row['status']) {
                            'paid' => 'bg-success',
                            'pending' => 'bg-warning text-dark',
                            'checked_in' => 'bg-primary',
                            default => 'bg-secondary'
                        };
                        ?>
                        <span class="badge <?= $status_class ?>"><?= ucfirst(str_replace('_', ' ', $row['status'])) ?></span>
                    </div>
                    
                    <?php if($row['status'] == 'paid'): ?>
                        <div class="text-center">
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=<?= $row['transaction_code'] ?>" alt="QR Code Tiket">
                            <div class="small text-muted mt-1">Siap untuk Check-in</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>