<?php
// cetak_tiket.php (Berada di ROOT folder SIMES)

require 'config.php';
// Pastikan fungsi checkLogin() dan clean() didefinisikan di config.php
checkLogin();

// Mengambil ID Transaksi (Primary Key) dari URL
$transaksi_pk_id = isset($_GET['id']) ? clean($_GET['id']) : ''; 
$user_id = $_SESSION['user_id'];

if (empty($transaksi_pk_id)) {
    // Jika ID kosong, kembalikan ke halaman tiket
    header("Location: {$base_url}peserta/my_tickets.php");
    exit;
}

// Query untuk mengambil semua detail tiket dan event
$sql_ticket_data = "
    SELECT 
        kode_transaksi, t.jumlah, t.status, t.total_bayar,
        e.title AS event_title, e.event_date, e.location,
        tt.nama_tiket,
        u.name AS user_name, u.email AS user_email -- Tambahkan Join User
    FROM transaksi t
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    JOIN users u ON t.user_id = u.id -- Join tabel users
    WHERE t.id = '$transaksi_pk_id' AND t.user_id = '$user_id'
";
$result_ticket = mysqli_query($conn, $sql_ticket_data);
$ticket_data = mysqli_fetch_assoc($result_ticket);

// Cek apakah data ditemukan dan status sudah PAID
if (mysqli_num_rows($result_ticket) == 0 || $ticket_data['status'] != 'PAID') {
    $error_msg = "Tiket tidak ditemukan atau status belum PAID. Silakan cek riwayat transaksi Anda.";
    // Kita akan tampilkan pesan error di dalam halaman
}

$qr_code_data = '';
if ($ticket_data && $ticket_data['status'] === 'PAID') {
    $qr_payload = implode(' | ', [
        'TRX:' . $ticket_data['kode_transaksi'],
        'USER:' . $user_id,
        'EVENT:' . $ticket_data['event_title']
    ]);

    $qr_code_data = urlencode($qr_payload);
}

// Data yang akan digunakan untuk QR Code (simulasi)
$qr_code_data = $ticket_data ? "TRXID: " . $ticket_data['kode_transaksi'] . " | USER: " . $_SESSION['user_id'] : "INVALID";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cetak Tiket - <?= $ticket_data['event_title'] ?? 'Error' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <style>
        @media print {
            body { 
                background: none; 
            }
            .no-print { 
                display: none; 
            }
            .ticket-container {
                box-shadow: none; 
                border: 1px solid #000;
                margin: 0;
            }
        }
        body {
            background-color: #f8f9fa;
        }
        .ticket-container {
            max-width: 800px;
            margin: 50px auto;
            border: 2px dashed #0d6efd;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .ticket-header {
            border-bottom: 2px solid #ccc;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .qr-placeholder {
            width: 150px;
            height: 150px;
            background-color: #eee;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            text-align: center;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>

    <div class="no-print text-center py-3 bg-white shadow-sm border-bottom">
        <a href="<?= $base_url ?>peserta/my_tickets.php" class="btn btn-secondary me-2">
            <i class="bi bi-arrow-left"></i> Kembali ke Tiket Saya
        </a>
        <?php if ($ticket_data): ?>
        <button onclick="window.print()" class="btn btn-primary">
            <i class="bi bi-printer"></i> Cetak Tiket
        </button>
        <?php endif; ?>
    </div>

    <?php if ($ticket_data): ?>
    <div class="ticket-container">
        <div class="ticket-header row align-items-center">
            <div class="col-8">
                <h1 class="text-primary"><?= htmlspecialchars($ticket_data['event_title']) ?></h1>
                <p class="lead">Tiket Tipe: <strong class="text-success"><?= htmlspecialchars($ticket_data['nama_tiket']) ?></strong></p>
            </div>
            <div class="col-4 text-end">
                <h6 class="text-muted mb-0"><?= SIMES_NAME ?? 'SIMES Event' ?></h6>
                <small class="text-secondary">Tiket Resmi</small>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <h4 class="mb-3 text-info"><i class="bi bi-person-fill me-1"></i> Detail Pemegang Tiket</h4>
                <table class="table table-borderless table-sm">
                    <tr>
                        <td style="width: 30%;">Nama Peserta</td>
                        <td style="width: 5%;">:</td>
                        <td><strong><?= htmlspecialchars($_SESSION['name']) ?></strong></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><?= htmlspecialchars($ticket_data['user_email'] ?? 'Tidak ada email') ?></td>
                    </tr>
                    <tr>
                        <td>ID Transaksi</td>
                        <td>:</td>
                        <td>#<?= htmlspecialchars($ticket_data['kode_transaksi']) ?></td>
                    </tr>
                    <tr>
                        <td>Jumlah Tiket</td>
                        <td>:</td>
                        <td><?= number_format($ticket_data['jumlah']) ?> pcs</td>
                    </tr>
                </table>

                <h4 class="mt-4 mb-3 text-info"><i class="bi bi-calendar-event me-1"></i> Detail Event</h4>
                <table class="table table-borderless table-sm">
                    <tr>
                        <td>Tanggal</td>
                        <td>:</td>
                        <td><strong><?= date('d F Y', strtotime($ticket_data['event_date'])) ?></strong></td>
                    </tr>
                    <tr>
                        <td>Lokasi</td>
                        <td>:</td>
                        <td><?= htmlspecialchars($ticket_data['location']) ?></td>
                    </tr>
                </table>
            </div>

            <div class="col-md-4 d-flex flex-column align-items-center justify-content-center">
                <div class="my-3 text-center">
                    <img 
                        src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?= $qr_code_data ?>"
                        alt="QR Code Tiket"
                        class="border p-2 bg-white"
                    >
                </div>
                <small class="text-danger fw-bold">Scan untuk Check-in</small>
            </div>
        </div>

        <div class="mt-4 pt-3 border-top text-center small text-muted">
            Tiket ini berlaku untuk satu kali masuk sesuai dengan detail yang tertera. Harap dibawa saat acara.
        </div>
    </div>
    <?php else: ?>
        <div class="container mt-5">
            <div class="alert alert-danger text-center p-4">
                <h4><i class="bi bi-exclamation-triangle-fill"></i> Gagal Memuat Tiket</h4>
                <p class="mb-0"><?= $error_msg ?? "Terjadi kesalahan yang tidak diketahui." ?></p>
            </div>
        </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>