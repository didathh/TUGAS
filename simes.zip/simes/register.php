<?php
// register.php

require 'config.php';

if (isLoggedIn()) {
    header("Location: index.php");
    exit;
}

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = clean($_POST['name']);
    $email = clean($_POST['email']);
    $password = clean($_POST['password']);
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Cek apakah email sudah terdaftar
    $check_user = mysqli_query($conn, "SELECT id FROM users WHERE email = '$email'");
    if (mysqli_num_rows($check_user) > 0) {
        $msg = '<div class="alert alert-danger">Email sudah terdaftar.</div>';
    } else {
        // Role default adalah 'peserta'
        $sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password_hash', 'user')";
        if (mysqli_query($conn, $sql)) {
            $msg = '<div class="alert alert-success">Pendaftaran berhasil! Silakan <a href="login.php" class="alert-link">Login</a>.</div>';
        } else {
            $msg = '<div class="alert alert-danger">Pendaftaran gagal.</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
    <style>
        .register-container { min-height: 100vh; display: flex; align-items: center; justify-content: center; background-color: #f8f9fa; }
        .register-card { max-width: 400px; width: 100%; }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="card register-card border-0 shadow-lg">
            <div class="card-header bg-warning text-dark text-center py-3">
                <h4 class="mb-0 fw-bold">SIMES REGISTER</h4>
            </div>
            <div class="card-body p-4">
                <p class="text-center text-muted">Daftar Akun Baru Peserta</p>
                <?= $msg ?>

                <form method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama Lengkap</label>
                        <input type="text" name="name" id="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-warning w-100 btn-lg mt-3">Daftar</button>
                </form>
                <p class="mt-4 text-center">Sudah punya akun? <a href="login.php" class="text-warning fw-bold">Login</a></p>
                <p class="mt-2 text-center"><a href="index.php" class="text-secondary"><i class="bi bi-arrow-left"></i> Kembali ke Beranda</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>