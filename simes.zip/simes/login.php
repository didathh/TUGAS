<?php
// login.php

require 'config.php';

/*
|--------------------------------------------------------------------------
| CEK JIKA SUDAH LOGIN
|--------------------------------------------------------------------------
*/
if (isLoggedIn() && isset($_SESSION['role'])) {
    $role = strtolower(trim($_SESSION['role']));

    switch ($role) {
        case 'admin':
            header("Location: admin/dashboard.php");
            break;
        case 'panitia':
            header("Location: panitia/dashboard.php");
            break;
        case 'user':
            header("Location: peserta/dashboard.php");
            break;
        default:
            // Role tidak valid → reset session
            session_destroy();
            header("Location: index.php");
    }
    exit;
}

$error = '';

/*
|--------------------------------------------------------------------------
| PROSES LOGIN
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = clean($_POST['email']);
    $password = $_POST['password']; // password tidak perlu clean()

    $sql = "SELECT id, name, email, password, role FROM users WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {

        // Normalisasi role (INI KUNCI UTAMA)
        $role = strtolower(trim($user['role']));

        // Validasi role yang diperbolehkan
        if (!in_array($role, ['admin', 'panitia', 'user'])) {
            session_destroy();
            $error = "Akun memiliki role tidak valid. Hubungi administrator.";
        } else {
            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['role']    = $role;

            // Redirect berdasarkan role
            switch ($role) {
                case 'admin':
                    header("Location: admin/dashboard.php");
                    break;
                case 'panitia':
                    header("Location: panitia/dashboard.php");
                    break;
                case 'user':
                    header("Location: peserta/dashboard.php");
                    break;
            }
            exit;
        }

    } else {
        $error = 'Email atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }
        .login-card {
            max-width: 400px;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="card login-card border-0 shadow-lg">
        <div class="card-header bg-primary text-white text-center py-3">
            <h4 class="mb-0 fw-bold">SIMES LOGIN</h4>
        </div>
        <div class="card-body p-4">
            <p class="text-center text-muted">Akses Dashboard Anda</p>

            <?php if ($error): ?>
                <div class="alert alert-danger text-center">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" autocomplete="off">
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email"
                           name="email"
                           id="email"
                           class="form-control"
                           required
                           autofocus>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password"
                           name="password"
                           id="password"
                           class="form-control"
                           required>
                </div>

                <button type="submit" class="btn btn-primary w-100 btn-lg mt-3">
                    Login
                </button>
            </form>

            <p class="mt-4 text-center">
                Belum punya akun?
                <a href="register.php" class="text-primary fw-bold">Daftar Sekarang</a>
            </p>

            <p class="mt-2 text-center">
                <a href="index.php" class="text-secondary">
                    <i class="bi bi-arrow-left"></i> Kembali ke Beranda
                </a>
            </p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
