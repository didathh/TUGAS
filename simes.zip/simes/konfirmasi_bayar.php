<?php
// konfirmasi_bayar.php (Berada di ROOT folder SIMES)

require 'config.php';
// Pastikan fungsi checkLogin(), clean(), dan variabel $base_url didefinisikan di config.php
checkLogin();

// Menggunakan ID (Primary Key) untuk kejelasan
$transaksi_pk_id = isset($_GET['id']) ? clean($_GET['id']) : ''; 
$user_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

if (empty($transaksi_pk_id)) {
    // Perbaikan: Redirect ke halaman tiket yang benar
    header("Location: {$base_url}peserta/my_tickets.php");
    exit;
}

// 1. Cek data transaksi
// Mengambil data lengkap transaksi, termasuk judul event dan total bayar
$sql_check = "
    SELECT 
        t.id, t.status, t.total_bayar, kode_transaksi, t.bukti_transfer, e.title 
    FROM transaksi t
    JOIN tipe_tiket tt ON t.tipe_tiket_id = tt.id
    JOIN events e ON tt.event_id = e.id
    WHERE t.id = '$transaksi_pk_id' AND t.user_id = '$user_id'
";
$res_check = mysqli_query($conn, $sql_check);

if (mysqli_num_rows($res_check) == 0) {
    die("<div class='alert alert-danger p-5 text-center'><h4>Transaksi tidak ditemukan.</h4> <a href='{$base_url}peserta/my_tickets.php' class='btn btn-primary'>Kembali ke Tiket Saya</a></div>");
}
$data_transaksi = mysqli_fetch_assoc($res_check);

// 2. Cek status sebelum proses POST
if ($data_transaksi['status'] != 'PENDING') {
    if ($data_transaksi['bukti_transfer']) {
        $message = "Bukti transfer Anda telah di-*upload* dan sedang menunggu verifikasi Admin.";
        $message_type = 'info';
    } else {
        $message = "Status transaksi bukan PENDING ({$data_transaksi['status']}). Tidak perlu upload.";
        $message_type = 'warning';
    }
}

// 3. Logika POST (Upload File)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $data_transaksi['status'] == 'PENDING') {
    
    // Pastikan ada file yang di-*upload*
    if (!isset($_FILES["bukti"]) || $_FILES["bukti"]["error"] != 0) {
        $message = "Silakan pilih file bukti transfer.";
        $message_type = 'danger';
    } else {
        $target_dir = "uploads/bukti_transfer/";
        // Pastikan folder ini ada: SIMES/uploads/bukti_transfer/
        
        $file_name_original = basename($_FILES["bukti"]["name"]);
        // Membuat nama file yang unik dan aman
        $file_name = "bukti_" . $data_transaksi['id'] . "_" . time() . "." . strtolower(pathinfo($file_name_original, PATHINFO_EXTENSION));
        $target_file = $target_dir . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Cek Tipe File
        if (!in_array($file_type, ["jpg", "png", "jpeg"])) {
            $message = "Hanya file JPG, JPEG, & PNG yang diizinkan.";
            $message_type = 'danger';
        } else {
            // Proses Upload
            if (move_uploaded_file($_FILES["bukti"]["tmp_name"], $target_file)) {
                
                // Update path bukti di database
                $sql_update = "UPDATE transaksi SET bukti_transfer = '$file_name' WHERE id = '{$data_transaksi['id']}'";
                mysqli_query($conn, $sql_update);
                
                $message = "Bukti transfer berhasil di-*upload*! Anda akan diarahkan kembali ke halaman tiket.";
                $message_type = 'success';
                // Perbaikan: Redirect yang benar dan cepat
                header("Refresh: 3; URL={$base_url}peserta/my_tickets.php");
            } else {
                $message = "Gagal meng-*upload* file. Cek izin folder uploads/bukti_transfer.";
                $message_type = 'danger';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Bukti Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="<?= $base_url ?>style.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-lg mx-auto" style="max-width: 600px;">
            <div class="card-header bg-warning text-dark fw-bold">
                <i class="bi bi-cash-stack me-2"></i> Konfirmasi Pembayaran
            </div>
            <div class="card-body">
                <h4 class="card-title"><?= htmlspecialchars($data_transaksi['title']) ?></h4>
                <p>ID Transaksi: **<?= htmlspecialchars($data_transaksi['kode_transaksi']) ?>**</p>
                <h5 class="text-danger">Total Bayar: **Rp <?= number_format($data_transaksi['total_bayar'], 0, ',', '.') ?>**</h5>
                
                <hr>
                <?php if ($message): ?>
                    <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
                        <?= $message ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($data_transaksi['status'] == 'PENDING' && empty($data_transaksi['bukti_transfer'])): ?>
                    <div class="alert alert-info small">
                        Silakan transfer ke rekening yang telah ditentukan, lalu unggah bukti pembayaran Anda di bawah ini.
                    </div>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="bukti" class="form-label">Pilih File Bukti Transfer (JPG/PNG)</label>
                            <input class="form-control" type="file" id="bukti" name="bukti" accept=".jpg, .jpeg, .png" required>
                            <small class="text-muted">Maksimal ukuran file: [Opsional: Tentukan batas ukuran]</small>
                        </div>
                        <button type="submit" class="btn btn-warning w-100 fw-bold"><i class="bi bi-upload me-1"></i> Kirim Bukti Pembayaran</button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-success text-center">
                        <i class="bi bi-check-circle-fill me-1"></i> Bukti Pembayaran sudah diterima.
                        <?php if($data_transaksi['bukti_transfer']): ?>
                            <br><small class="text-muted">File: <?= htmlspecialchars($data_transaksi['bukti_transfer']) ?></small>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer text-end">
                <a href="<?= $base_url ?>peserta/my_tickets.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i> Kembali ke Tiket Saya</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>